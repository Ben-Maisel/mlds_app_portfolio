#Imports
import socket
import re
import sys
import os

if len(sys.argv) > 2:
    sys.exit("TOO MANY ARGS PASSED")

try:
    port_number = int(sys.argv[1])
    if port_number < 1024:
        sys.exit("RESERVED PORT NUMBER")
except ValueError:
    sys.exit("PORT NUMBER MUST BE INT")



ipv4 = socket.AF_INET
TCP = socket.SOCK_STREAM

def create_socket(ipv = ipv4, protocol = TCP):
    server_socket =  socket.socket(ipv, protocol)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('', port_number))
    server_socket.listen(10)
    return server_socket

def send_response(connection_socket, status_code, content_type, body):
    http_response = f"HTTP/1.1 {status_code}\r\n"
    http_response += f"Content-Type: {content_type}\r\n"
    http_response += "Connection: close\r\n\r\n"
    connection_socket.sendall(http_response.encode())
    if body:
        connection_socket.sendall(body)

def handle_request(connection_socket):
    request = connection_socket.recv(2048).decode()

 
    if not request:
        print("Received an empty request")
        connection_socket.close()
        return

    request_lines = request.splitlines()
    if len(request_lines) == 0:
        print("Invalid request received")
        connection_socket.close()
        return

    request_line = request.splitlines()[0]
    request_method, path, _ = request_line.split()

    if request_method != "GET":
        send_response(connection_socket, "405 Method Not Allowed", "text/plain", b"405 Method Not Allowed")
        return


    if path == "/":
        path = "/index.html"  

    file_path = path.lstrip("/") 


    
    if not (file_path.endswith(".html") or file_path.endswith(".htm")):
        send_response(connection_socket, "403 Forbidden", "text/plain", b"403 Forbidden")
    elif not os.path.isfile(file_path):
        send_response(connection_socket, "404 Not Found", "text/plain", b"404 Not Found")
    else:

        with open(file_path, 'rb') as f:
            file_content = f.read()
        send_response(connection_socket, "200 OK", "text/html", file_content)

def start_server():
    server_socket = create_socket()

    while True:
        connection_socket, client_address = server_socket.accept()
        handle_request(connection_socket)
        connection_socket.close()

start_server()