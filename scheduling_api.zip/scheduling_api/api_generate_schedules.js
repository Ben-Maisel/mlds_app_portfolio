// post command to generate schedules and stick them in aws and rds

const dbConnection = require('./database.js')                    //we need this import to access amazon and our sql database
const { cabins, activities, units, otherValidActivities, cabinToIdMap, activityToIdMap } = require('./data.js')
const { Schedule } = require('./class_definitions.js')
const { getRandomActivity, assignRandomSchedules } = require('./function_definitions.js')
const { PutObjectCommand } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');
const { v4: uuidv4 } = require('uuid');

async function s3Upload(data, filename) { //helper function to upload the generated schedules to S3
  const params = {
    Bucket: s3_bucket_name,  //parameters needed for upload to work
    Key: filename,
    Body: JSON.stringify(data)
  };

  try {
    await s3.send(new PutObjectCommand(params)); // wait for the data to be put in the bucket
    // console.log('Successfully uploaded to s3');
    return filename; //return key after uploading so we can stick it in rds
  } catch (err) {
    console.error("Error uploading to s3 :", err); //catch any errors
    throw err;
    }
};



async function updateActivitiesCurrentScheduleKeyInDb(key, activity) { //helper function to update sql table with current schedule key
  const query = 'UPDATE activities SET current_schedule_key = ? WHERE activityid = ?';
  const values = [key, activityToIdMap.get(activity)];

  try {
    await dbConnection.query(query, values);
    console.log(`Successfully updated current schedule key for ${activity}`);
  } catch(err) {
    console.error(`Error updating current schedule key for ${activity}`);
    throw err;
  }
};

async function updateCabinsCurrentScheduleKeyInDb(key, schedule) { //helper function to update sql table with current schedule key
  const query = 'UPDATE cabins SET current_schedule_key = ? WHERE cabinid = ?';
  const values = [key, cabinToIdMap.get(schedule.cabin)];

  try {
    await dbConnection.query(query, values);
    console.log(`Successfully updated current schedule key for ${schedule.cabin}`);
  } catch(err) {
    console.error(`Error updating current schedule key for ${schedule.cabin}`);
    throw err;
  }
};

async function insertCabinScheduleKeyInDb(key, schedule) { //helper function to insert schedule into rds
  const query = 'INSERT INTO cabin_schedules (cabinid, cabin_schedule_date, cabin_schedule_key) VALUES (?, (SELECT NOW()), ?)';
  const values = [cabinToIdMap.get(schedule.cabin), key];

  try {
    await dbConnection.query(query, values);
    // console.log(`Successfully inserted schedule key`);
  } catch(err) {
    console.error(`Error inserting schedule key`);
    throw err;
  }
};

async function insertActivityScheduleKeyInDb(key, activity) { //helper function to insert schedule into rds
  const query = 'INSERT INTO activity_schedules (activityid, activity_schedule_date, activity_schedule_key) VALUES (?, (SELECT NOW()), ?)';
  const values = [activityToIdMap.get(activity), key];

  try {
    await dbConnection.query(query, values);
    // console.log(`Successfully inserted schedule key`);
  } catch(err) {
    console.error(`Error inserting schedule key`);
    throw err;
  }
};


exports.generate_schedules = async (req, res) => { //export and make async
  console.log('call to /generate_schedules...');
  try {
    console.log('generating schedules...');
    const requests = Array.isArray(req.body) ? req.body : []; //get requests from post command
    const { cabinSchedules, activitySchedules } = assignRandomSchedules(requests); //call function with requests object and store results

    for (const schedule of cabinSchedules) { //for each schedule in our cabin schedules response
      const filename = `cabin-schedules/${schedule.cabin}-${uuidv4()}.json`; //upload to the cabinschedules 'folder' under the cabin name
      const key = await s3Upload(schedule, filename); //upload and wait
      await updateCabinsCurrentScheduleKeyInDb(key, schedule); //update current schedule key for the activity
      await insertCabinScheduleKeyInDb(key, schedule); //stick schedule in rds
    }

    for (const [activity, schedule] of Object.entries(activitySchedules)) { // same for the activitiy schedules
      const filename = `activity-schedules/${uuidv4()}.json`;
      const key = await s3Upload(schedule, filename);
      await updateActivitiesCurrentScheduleKeyInDb(key, activity);
      await insertActivityScheduleKeyInDb(key, activity);
      
    }

    console.log('finished uploading schedules');
    res.status(200).json({ "message": "Success! Schedules generated and uploaded to S3 and RDS" });
      
  } catch(err) {
    console.error("Error generating and  uploading schedules:", err);
    res.status(400).json({ "message": err.message });
    }
};

    



    
    
   