from tictactoe import TicTacToe
import math
import random
import time


def minimax(board, depth, maximizing_player, ai_player):

    # The board parameter represents the current state of the game
    # The depth parameter is how many moves we want to be looking ahead
    # maximizing_player is a boolean indictating if it the AI's turn
    # ai_player is just the letter that the ai player is using
    # The function must return the square on the board that is the optimal move

    human_player = 'X' # ai player is O so human is X

    # TERMINAL GAME STATES
    if board.current_winner == ai_player:
        return {'score':1 * (depth + 1), 'position':None}            # if the game has a winner, dont make a move and break the loop, ai player is maximizer so return 1, use depth so that immeditate winning moves are scored higher
    elif board.current_winner == human_player:
        return {'score':-1 * (depth + 1), 'position':None}            # if the game has a winner, dont make a move and break the loop, ai player is maximizer so return -1, use depth so that immediate winning moves are scored lower
    elif board.num_empty_squares() == 0:
        return {'score':0, 'position':None}            # if no more moves, game is over, ended in a draw
    
    
    
    if maximizing_player: #if it is the ai turn, set the best score to -inf and set the player to AI
        best_score = -math.inf
        player = ai_player
    else:
        best_score = math.inf # otherwise, the player is the human player so set the best score to inf and set the player to human
        player = human_player

    best_move = None # to start, we have not explored any moves so set the best move to none. If we find a better move, update the best move to that move

    # Now that the players have been initialized and we have made a variable to keep track of the best move, we must iterate through all moves to find the best one
    for move in board.available_moves(): # iterate through all possible moves

        board.make_move(move, player) # first things first, we must actually make the move

        score = minimax(board, depth - 1, not maximizing_player, ai_player)['score']
        '''
        There is a lot going on in this line
        We are reccursively calling the function over and over again until we reach one of the terminal game states outlined above.
        When this happens, we will not enter another reccursive call causing this loop to break. 
        Each reccursive call will make another move on the updated board until either a winner is found or no more moves are left.
        Since we are making this call with all possible moves (we are doing this within the forloop), this reccurssive call effectively creates a tree
        where each child is the same game state of the parent + 1 move. We explore all the paths down from the current game state to the leaves of the tree
        It is not entirely needed to decrement the depth here, as doing so is a little redundant, but this will ensure the algorithm will still work if
        we do not want to explore each path down to the leaves.
        not maximizing player switches which player is making a move in the child node of the current game state.
        This effectively causes the computer to similate each move the opponenet can make in response to the move the maximizing player made exploring all
        possible ways that the game can play out. 
        ''' 
        board.board[move] = ' ' # after we make a move and similate all possible ways the game can play out, we need to do the same for the next move
                                # before we can repeat the process, we must reset the board to the game state the function was called on
                                # this ensures that each move and resulting tree is explored independently of all other moves and resulting trees
        

        board.current_winner = None #make sure we dont set a winner while simulating games

        if maximizing_player: #recall that in this algorithm, the maximizing player is trying to get the highest score possible
            if score > best_score: # if we find a score better than what we've got, 
                best_score = score # set it to the new score 
                best_move = move # and make that move that maximizes the score the best move
        
        else: # otherwise, we are the minimizing player and so we want to make the move that will result in the lowest score.
            if score < best_score: #if we find a score lower than what we've got
                best_score = score # set it to the new score
                best_move = move # make the move that minimizes the score the best move

    return {'score':best_score, 'position':best_move}


#--------------------------------------------------------------------------------------------------------------------------------------------------------#

def minimax_with_alpha_beta(board, depth, alpha, beta, maximizing_player, ai_player):

    # The board parameter represents the current state of the game
    # The depth parameter is how many moves we want to be looking ahead
    # alpha is the best possible score the maximizing player can get at that level of the similation
    # beta is the lowest possible score the minimizing player can for the maximizing player to get at that level of the similation
    # maximizing_player is a boolean indictating if it the AI's turn
    # ai_player is just the letter that the ai player is using
    # The function must return the square on the board that is the optimal move

    human_player = 'X' # ai player is O so human is X

    # TERMINAL GAME STATES
    if board.current_winner == ai_player:
        return {'score':1 * (depth + 1), 'position':None}            # if the game has a winner, dont make a move and break the loop, ai player is maximizer so return 1, use depth so that immeditate winning moves are scored higher
    elif board.current_winner == human_player:
        return {'score':-1 * (depth + 1), 'position':None}            # if the game has a winner, dont make a move and break the loop, ai player is maximizer so return -1, use depth so that immediate winning moves are scored lower
    elif board.num_empty_squares() == 0:
        return {'score':0, 'position':None}            # if no more moves, game is over, ended in a draw
    
    
    if maximizing_player: #if it is the ai turn, set the best score to -inf and set the player to AI
        best_score = -math.inf
        player = ai_player
    else:
        best_score = math.inf # otherwise, the player is the human player so set the best score to inf and set the player to human
        player = human_player

    best_move = None # to start, we have not explored any moves so set the best move to none. If we find a better move, update the best move to that move

    # Now that the players have been initialized and we have made a variable to keep track of the best move, we must iterate through all moves to find the best one
    for move in board.available_moves(): # iterate through all possible moves

        board.make_move(move, player) # first things first, we must actually make the move

        score = minimax_with_alpha_beta(board, depth-1, alpha, beta, not maximizing_player, ai_player)['score']
        '''
        There is a lot going on in this line
        We are reccursively calling the function over and over again until we reach one of the terminal game states outlined above.
        When this happens, we will not enter another reccursive call causing this loop to break. 
        Each reccursive call will make another move on the updated board until either a winner is found or no more moves are left.
        Since we are making this call with all possible moves (we are doing this within the forloop), this reccurssive call effectively creates a tree
        where each child is the same game state of the parent + 1 move. We explore all the paths down from the current game state to the leaves of the tree
        It is not entirely needed to decrement the depth here, as doing so is a little redundant, but this will ensure the algorithm will still work if
        we do not want to explore each path down to the leaves.
        not maximizing player switches which player is making a move in the child node of the current game state.
        This effectively causes the computer to similate each move the opponenet can make in response to the move the maximizing player made exploring all
        possible ways that the game can play out. 
        ''' 
        board.board[move] = ' ' # after we make a move and similate all possible ways the game can play out, we need to do the same for the next move
                                # before we can repeat the process, we must reset the board to the game state the function was called on
                                # this ensures that each move and resulting tree is explored independently of all other moves and resulting trees
        
        board.current_winner = None #make sure we dont set a winner while simulating games
        
        if maximizing_player: #recall that in this algorithm, the maximizing player is trying to get the highest score possible
            if score > best_score: # if we find a score better than what we've got, 
                best_score = score # set it to the new score 
                best_move = move # and make that move that maximizes the score the best move
            if alpha < score: # alpha should always be the highest possible score at that level 
                alpha = score # so if we find a better score, update alpha
            if beta < alpha: # if beta is less than alpha, the minimizing player will never let the maximizing player make this move if they are playing optimally 
                             #so break the loop and prune the tree here
                break
        
        else: # otherwise, we are the minimizing player and so we want to make the move that will result in the lowest score.
            if score < best_score: #if we find a score lower than what we've got
                best_score = score # set it to the new score
                best_move = move # make the move that minimizes the score the best move
            if beta > score: # beta should always be the lowest possible score at that level
                beta = score # so if we find a lower score, change beta
            if beta < alpha: # if beta is less than alpha, the minimizing player will never let the maximizing player make this move if they are playing optimally 
                             #so break the loop and prune the tree here
                break

    return {'score':best_score, 'position':best_move}



#--------------------------------------------------------------------------------------------------------------------------------------------------------#


def play_game_human_moves_first():

    game = TicTacToe()
    print("\nInitial Board:")
    game.print_board()

    letter = 'X'  # Human player starts first.
    while game.empty_squares_available():
        if letter == 'O':  # AI's turn
            square = minimax_with_alpha_beta(game, len(game.available_moves()), -math.inf, math.inf, True, 'O')['position']
            if square is None:
                print("\nGame is a draw!")
                break
            game.make_move(square, letter)
            print(f"\nAI (O) chooses square {square + 1}")
        else:
            valid_square = False
            while not valid_square:
                square = input(f"\n{letter}'s turn. Input move (1-9): ")
                try:
                    square = int(square) - 1
                    if square not in game.available_moves():
                        raise ValueError
                    valid_square = True
                    game.make_move(square, letter)
                except ValueError:
                    print("\nInvalid square. Try again.")

        game.print_board()

        if game.current_winner:
            print(f"\n{letter} wins!")
            break

        letter = 'O' if letter == 'X' else 'X'  # Switch turns.
    else:
        print("\nIt's a draw!")

def play_game_ai_moves_first():

    game = TicTacToe()
    print("\nInitial Board:")
    game.print_board()

    first_move = True

    letter = 'O'  # AI player starts first.
    while game.empty_squares_available():
        if letter == 'O':  # AI's turn
            if first_move:
                square = random.randint(0, 8)
                first_move = False
            else:
                square = minimax_with_alpha_beta(game, len(game.available_moves()), -math.inf, math.inf, True, 'O')['position']
            if square is None:
                print("\nGame is a draw!")
                break
            game.make_move(square, letter)
            print(f"\nAI (O) chooses square {square + 1}")
        else:
            valid_square = False
            while not valid_square:
                square = input(f"\n{letter}'s turn. Input move (1-9): ")
                try:
                    square = int(square) - 1
                    if square not in game.available_moves():
                        raise ValueError
                    valid_square = True
                    game.make_move(square, letter)
                except ValueError:
                    print("\nInvalid square. Try again.")

        game.print_board()

        if game.current_winner:
            print(f"\n{letter} wins!")
            break

        letter = 'O' if letter == 'X' else 'X'  # Switch turns.
    else:
        print("\nIt's a draw!")

def play_game_human_vs_human():

    game = TicTacToe()
    print("\nInitial Board:")
    game.print_board()

    letter = 'O'  # Human (O) player starts first.
    while game.empty_squares_available():
        if letter == 'O':  # Human (O)'s turn
            valid_square = False
            while not valid_square:
                square = input(f"\n{letter}'s turn. Input move (1-9): ")
                try:
                    square = int(square) - 1
                    if square not in game.available_moves():
                        raise ValueError
                    valid_square = True
                    game.make_move(square, letter)
                except ValueError:
                    print("\nInvalid square. Try again.")

                if square is None:
                    print("\nGame is a draw!")
                    break
                game.make_move(square, letter)
                print(f"\nAI (O) chooses square {square + 1}")
        else:
            valid_square = False
            while not valid_square:
                square = input(f"\n{letter}'s turn. Input move (1-9): ")
                try:
                    square = int(square) - 1
                    if square not in game.available_moves():
                        raise ValueError
                    valid_square = True
                    game.make_move(square, letter)
                except ValueError:
                    print("\nInvalid square. Try again.")

        game.print_board()

        if game.current_winner:
            print(f"\n{letter} wins!")
            break

        letter = 'O' if letter == 'X' else 'X'  # Switch turns.
    else:
        print("\nIt's a draw!")

def play_game_ai_vs_ai():

    game = TicTacToe()
    print("\nInitial Board:")
    game.print_board()

    first_move = True

    letter = 'O'  # AI (O) player starts first.
    while game.empty_squares_available():
        if letter == 'O':  # AI (O)'s turn
            if first_move:
                square = random.randint(0, 8)
                first_move = False
            else:
                square = minimax_with_alpha_beta(game, len(game.available_moves()), -math.inf, math.inf, True, 'O')['position']
            if square is None:
                print("\nGame is a draw!")
                break
            game.make_move(square, letter)
            print(f"\nAI (O) chooses square {square + 1}")
            time.sleep(0.75)
        else:
            square = minimax_with_alpha_beta(game, len(game.available_moves()), -math.inf, math.inf, True, 'O')['position']
            if square is None:
                print("\nGame is a draw!")
                break
            game.make_move(square, letter)
            print(f"\nAI (X) chooses square {square + 1}")
            time.sleep(0.75)

        game.print_board()

        if game.current_winner:
            print(f"\n{letter} wins!")
            break

        letter = 'O' if letter == 'X' else 'X'  # Switch turns.
    else:
        print("\nIt's a draw!")


if __name__ == '__main__':

    print("""
Modes of play available:

    hh: Hooman vs. hooman
    ha: Hooman vs. AI
    ah: AI vs. Hooman - AI makes first move
    aa: AI vs. AI""")

    valid_move = False
    while not valid_move:
        mode = input("\nEnter preferred mode of play (e.g., aa): ")
        try:
            if mode not in ["hh", "ha", "ah", "aa"]:
                raise ValueError
            valid_move = True
            if mode == "hh":
                play_game_human_vs_human()
            elif mode == "ha":
                play_game_human_moves_first()
            elif mode == "ah":
                play_game_ai_moves_first()
            else:
                play_game_ai_vs_ai()
        except ValueError:
            print("\nInvalid option entered. Try again.")

