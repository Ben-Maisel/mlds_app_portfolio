// here are the definitions for classes I will use throughout this project

class Day {
  constructor() {
    this.periods = [[], [], [], []];  //NOTE --> come back here and add 5th period option once the rest is complete
  }

  addActivity(period, item) {
    if (!this.periods[period].includes(item)) {     //method that checks if given period is null and if it is, set it to the activity
      this.periods[period].push(item);
      return true;
    }
    return false;
  }

  isActivityScheduled(activity) {
    return this.periods.includes(activity);  //method that checks if a given activity exists in a day
  }

  getActivities() {
    return {
      period1 : this.periods[0],
      period2 : this.periods[1], //method that returns the activities in a day
      period3 : this.periods[2],
      period4 : this.periods[3],
    }
    
    
  }
}

class Schedule {
  constructor(days = 7) {
    this.days = [];
    for (let i = 0; i < days; i++) { //create a schedule that has 7 days
      this.days.push(new Day());
    }
  }

  getSchedule() {
    let fullSchedule = []; 
    for (let i = 0; i < this.days.length; i++) { 
      fullSchedule.push(this.days[i].getActivities()); // Collect activities from each day
    }
    return fullSchedule; // Return the full schedule 
  }
}

module.exports = {         
  Schedule
};