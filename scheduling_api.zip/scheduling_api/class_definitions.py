class Cabin:

  def __init__(self, cabinid, cabin_name, current_schedule_key):
    self.cabinid = cabinid
    self.cabin_name = cabin_name
    self.current_schedule_key = current_schedule_key

class Activity:

  def __init__(self, activityid, activity_name, current_schedule_key):
    self.activityid = activityid
    self.activity_name = activity_name
    self.current_schedule_key = current_schedule_key

class CabinSchedule:

  def __init__(self, cabinName, cabinId, schedule):
    self.cabinName = cabinName
    self.cabinId = cabinId
    self.schedule = schedule

class PastCabinSchedule:

  def __init__(self, cabinName, cabinId, scheduleId, schedule_date, schedule):
    self.cabinName = cabinName
    self.cabinId = cabinId
    self.scheduleId = scheduleId
    self.schedule_date = schedule_date
    self.schedule = schedule

class ActivitySchedule:

  def __init__(self, activityName, activityId, schedule):
    self.activityName = activityName
    self.activityId = activityId
    self.schedule = schedule

class PastActivitySchedule:

  def __init__(self, activityName, activityId, scheduleId, schedule_date, schedule):
    self.activityName = activityName
    self.activityId = activityId
    self.scheduleId = scheduleId
    self.schedule_date = schedule_date
    self.schedule = schedule
    