library(shiny)
library(sf)
library(ggplot2)
library(bslib)
library(dplyr)

county_data <- sf::read_sf("data/county_data.shp")


states <- unique(county_data$state)
states <- tools::toTitleCase(states)

ui <- page_sidebar(
  title = "County Demographic Map by State",
  sidebar = sidebar(
    width = 300,
    tags$p("Create demographic maps with information from the 2010 US Census."),
    selectInput(
      inputId = "state",
      label = tags$b("Choose a state to display"),
      choices = states,
      selected = "Alabama"
    ),
    selectInput(
      inputId = "variable",
      label = tags$b("Choose a variable to display"),
      choices = list(
        "Percent White" = "white",
        "Percent Black" = "black",
        "Percent Hispanic" = "hispanic",
        "Percent Asian" = "asian"
      ),
      selected = "white"
    )
  ),
  plotOutput(outputId = "map")
)

server <- function(input, output, session) {
  output$map <- renderPlot({
    state_data <- county_data %>% filter(state == tolower(input$state))
    state_data <- state_data %>%
      select(state, county, geometry, white, black, hispanic, asian)
    
    state_data$white <- as.numeric(unlist(state_data$white))
    state_data$black <- as.numeric(unlist(state_data$black))
    state_data$hispanic <- as.numeric(unlist(state_data$hispanic))
    state_data$asian <- as.numeric(unlist(state_data$asian))
    
    var <- input$variable
    color <- switch(var,
                    "white" = "darkgreen",
                    "black" = "black",
                    "hispanic" = "darkorange",
                    "asian" = "darkviolet")
    
    ggplot(data = state_data) +
      geom_sf(aes_string(fill = var), color = "black", size = 0.2) +
      scale_fill_gradient(low = "white", high = color, limits = c(0, 100), name = paste0("% ", tools::toTitleCase(var))) +
      theme_void() +
      theme(
        legend.position = "right",
        plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
        legend.title = element_text(face = "bold")
      ) +
      labs(title = tools::toTitleCase(input$state), fill = paste0("% ", tools::toTitleCase(var)))
  })
}

shinyApp(ui = ui, server = server)
