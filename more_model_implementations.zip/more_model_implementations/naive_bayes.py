import math
import re

class Bayes_Classifier:

    def __init__(self):
        # initialize some trackers to keep count of positive vs negative reviews and words
        self.positive_reviews_count = 0
        self.negative_reviews_count = 0
        self.total_reviews_count = 0
        self.positive_word_counts = {}
        self.negative_word_counts = {}
        self.vocab = set()
        self.punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
        self.stop_words = ['a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
              'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
              'to', 'was', 'were', 'will', 'with', 'i', 'ive', 'me']
        
    def naive_stem(word):
        suffixes = ['ing', 'ly', 'ed', 'ious', 'ies', 'ive', 'es', 's', 'ment']
        # Check for the longest suffix to remove
        for suffix in sorted(suffixes, key=len, reverse=True):
            # If the suffix is found at the end of the word, strip it off
            if word.endswith(suffix):
                return word[:-len(suffix)]
        return word 



    def train(self, lines):
        for line in lines:
        # process training data the same way as below
            components = line.split('|')
            rating = components[0]
            review_text = components[2].lower()
            review_text = ''.join(char for char in review_text if char not in self.punctuation)

            review_text = review_text.split()
            review_text = " ".join(word for word in review_text if word not in self.stop_words)

            review_text = " ".join(Bayes_Classifier.naive_stem(word) for word in review_text.split())


            # update trackers
            if rating == '5':
                self.positive_reviews_count += 1
            elif rating == '1':
                self.negative_reviews_count += 1

            words = review_text.split()
            for word in words:
                self.vocab.add(word)
                if rating == '5':
                    self.positive_word_counts[word] = self.positive_word_counts.get(word, 0) + 1
                elif rating == '1':
                    self.negative_word_counts[word] = self.negative_word_counts.get(word, 0) + 1

        self.total_reviews_count = self.positive_reviews_count + self.negative_reviews_count

        self.prior_prob_positive = self.positive_reviews_count / self.total_reviews_count
        self.prior_prob_negative = self.negative_reviews_count / self.total_reviews_count

        self.total_positive_words = sum(self.positive_word_counts.values())
        self.total_negative_words = sum(self.negative_word_counts.values())
        self.vocab_size = len(self.vocab)

        self.positive_word_probs = {word: (self.positive_word_counts.get(word, 0) + 1) / 
                                          (self.total_positive_words + self.vocab_size) for word in self.vocab}
                                
        self.negative_word_probs = {word: (self.negative_word_counts.get(word, 0) + 1) / 
                                          (self.total_negative_words + self.vocab_size) for word in self.vocab}


        


    def classify(self, lines):
        predictions = []
        
        for line in lines:

            # preprocess the line the same way we did for the training
            review_text = line.lower()
            review_text = ''.join(char for char in review_text if char not in self.punctuation)

            review_text = review_text.split()
            review_text = " ".join(word for word in review_text if word not in self.stop_words)

            review_text = " ".join(Bayes_Classifier.naive_stem(word) for word in review_text.split())

            # initialize log probablitities for each class
            log_prob_positive = math.log(self.prior_prob_positive)
            log_prob_negative = math.log(self.prior_prob_negative)

            # Calculate the sum of log probabilities for each word in the review
            for word in review_text.split():
                if word in self.vocab:
                    log_prob_positive += math.log(self.positive_word_probs.get(word, 1 / (self.total_positive_words + self.vocab_size)))
                    log_prob_negative += math.log(self.negative_word_probs.get(word, 1 / (self.total_negative_words + self.vocab_size)))

            # Predict based on which probability is higher
            if log_prob_positive > log_prob_negative:
                predictions.append('5')
            else:
                predictions.append('1')
    
        return predictions
        



'DONE'

reviews = []


# parse the text
with open('alldata.txt', 'r', encoding='utf-8') as file:
    for line in file:
        reviews.append(line.strip())  # strip() removes the newline character at the end of each line

# processing

# add-one smoothing            DONE(?)
# removing capitalization      DONE
# removing punctuation         DONE
# removing stop words          DONE (maybe remove pronouns)
# stemming                     DONE
# TF-IDF                       DONE
# bigrams









# first, split each review into its parts
reviews = [review.split('|') for review in reviews]

# seperate the good and bad reviews

good_reviews = [review for review in reviews if review[0] == '5']

bad_reviews = [review for review in reviews if review[0] == '1']

# we just want the text from the review, so only keep that part

good_reviews = [review[2] for review in good_reviews]
bad_reviews = [review[2] for review in bad_reviews]

# next, we want to standardize the text

good_reviews = [review.lower() for review in good_reviews]
bad_reviews = [review.lower() for review in bad_reviews]

punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'

good_reviews = [''.join(char for char in review if char not in punctuation) for review in good_reviews]
bad_reviews = [''.join(char for char in review if char not in punctuation) for review in bad_reviews]

stop_words = ['a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
              'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
              'to', 'was', 'were', 'will', 'with', 'i', 'ive', 'me']

good_reviews = [review.split() for review in good_reviews]
good_reviews = [" ".join(word for word in review if word not in stop_words) for review in good_reviews]

bad_reviews = [review.split() for review in bad_reviews]
bad_reviews = [" ".join(word for word in review if word not in stop_words) for review in bad_reviews]


# helper for stemming
def naive_stem(word):
    suffixes = ['ing', 'ly', 'ed', 'ious', 'ies', 'ive', 'es', 's', 'ment']
    # Check for the longest suffix to remove
    for suffix in sorted(suffixes, key=len, reverse=True):
        # If the suffix is found at the end of the word, strip it off
        if word.endswith(suffix):
            return word[:-len(suffix)]
    return word

#stemming
good_reviews = [" ".join(naive_stem(word) for word in review.split()) for review in good_reviews]
bad_reviews = [" ".join(naive_stem(word) for word in review.split()) for review in bad_reviews]





# term sets
good_terms_set = set()
bad_terms_set = set()

for review in good_reviews:
    for word in review.split():
        good_terms_set.add(word)

for review in bad_reviews:
    for word in review.split():
        bad_terms_set.add(word)

#term dicts to keep track of frequency
good_terms_frequency = {word : 0 for word in good_terms_set}
bad_terms_frequency = {word : 0 for word in bad_terms_set}

for review in good_reviews:
    for word in review.split():
        good_terms_frequency[word] += 1

for review in bad_reviews:
    for word in review.split():
        bad_terms_frequency[word] += 1

# IDF STUFF
good_terms_idf = {}
bad_terms_idf = {}

# TOTAL TERMS
total_good_words = sum(good_terms_frequency.values())
total_bad_words = sum(bad_terms_frequency.values())
total_words = total_good_words + total_bad_words

# IDF SCORES
for key in good_terms_frequency.keys():
    good_terms_idf[key] = math.log(total_words / (good_terms_frequency.get(key, 0) + bad_terms_frequency.get(key, 0) + 1))  # + 1 to ensure we never divide by 0


for key in bad_terms_frequency.keys():
    bad_terms_idf[key] = math.log(total_words / (good_terms_frequency.get(key, 0) + bad_terms_frequency.get(key, 0) + 1))

good_term_scores = {k: good_terms_frequency[k] * good_terms_idf[k] for k in good_terms_frequency.keys()}
bad_term_scores = {k: bad_terms_frequency[k] * bad_terms_idf[k] for k in bad_terms_frequency.keys()}



print(good_term_scores)

