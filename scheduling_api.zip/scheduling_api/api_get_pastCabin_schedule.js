// get request to return past cabin schedules from our sql database

const dbConnection = require('./database.js');                    
const { cabinToIdMap } = require('./data.js');
const { GetObjectCommand } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');
const { streamToString } = require('./function_definitions.js');



exports.get_pastCabin_schedule = async (req, res) => {
  console.log('call to /get_pastCabin_schedules...');
  try {
    const cabinsRequesting = Array.isArray(req.body) ? req.body : []; // Get cabins from request body

    const cabinIds = cabinsRequesting.map(cabin => cabinToIdMap.get(cabin)).filter(id => id !== undefined); //only get valid cabin ids

    if (cabinIds.length === 0) {
      return res.status(400).json({ message: "No valid cabin IDs found in the request." }); //if no cabins, error
    }

    const query = 'SELECT cabin_name, cabinid, cabin_scheduleid, cabin_schedule_date, cabin_schedule_key FROM cabin_schedules NATURAL JOIN cabins  WHERE cabinid IN (?)'; 

    // Query the database
    const rows = await new Promise((resolve, reject) => {  //make query and store results
      dbConnection.query(query, [cabinIds], (err, results) => {
        if (err) {
          return reject(err); //this will cause the promise to be rejected if there is an error
        }
        resolve(results); //if there is no error, resolve the results to fullfill the promise
      });
    });

    if (!rows || rows.length === 0) {
      return res.status(404).json({ message: "No schedules found for the requested cabins." }); //if no schedules, error
    }


    const schedule_data = rows.map(row => ({
      cabinName : row.cabin_name,//format the rds response
      cabinId: row.cabinid,
      scheduleId: row.cabin_scheduleid,
      schedule_date : row.cabin_schedule_date,
      scheduleKey: row.cabin_schedule_key
    }));

    schedules = []; //structure to return the schedules

    for (const item of rows) { // for each cabin, get the schedule from s3 and stick it in return structure
      const command = new GetObjectCommand({
        Bucket: s3_bucket_name,
        Key: item.cabin_schedule_key
      });

      const response = await s3.send(command);
      const contents = await streamToString(response.Body); //our helper function defined in function defintions
      const contents_formatted = JSON.parse(contents);
      schedules.push({ cabinName : item.cabin_name, cabinId: item.cabinid, 
                      scheduleId : item.cabin_scheduleid, schedule_date: item.cabin_schedule_date, 
                      schedule: contents_formatted.schedule });
    }


    console.log("Done!")
    res.status(200).json({ message: "Schedules retrieved successfully", data: schedules });

  } catch (err) {
    console.error("message: ", err);
    res.status(400).json({ message: "Error retrieving schedules", error: err.message });
  }
};

