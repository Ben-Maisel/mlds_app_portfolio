from simulator.node import Node
import math

class Link_State_Node(Node):

    def __init__(self, id):
        super().__init__(id)
        self.neighbors = []
        self.topology = {}  # node id => {neighbor id => latency}
        self.routes = {}
        self.processed_messages = {}  # origin id => sequence number
        self.sequence_number = 0  # For messages originated by this node

    def __str__(self):
        return f"Node ID: {self.id}\nNeighbors: {self.neighbors}\nTopology: {self.topology}\nRoutes: {self.routes}"

    def link_has_been_updated(self, neighbor, latency):
        if latency == -1:
            if neighbor in self.neighbors:
                self.neighbors.remove(neighbor)
            if self.id in self.topology:
                self.topology[self.id].pop(neighbor, None)
            if neighbor in self.topology:
                self.topology.pop(neighbor, None)
        else:
            if neighbor not in self.neighbors:
                self.neighbors.append(neighbor)
            if self.id not in self.topology:
                self.topology[self.id] = {}
            self.topology[self.id][neighbor] = latency

        self.calculate_dijkstra()

        message = {
            'origin': self.id,
            'sender': self.id,
            'topology': {self.id: self.topology.get(self.id, {})},
            'sequence': self.sequence_number
        }
        self.sequence_number += 1
        self.send_to_neighbors(message)

    def process_incoming_routing_message(self, m):
        origin = m['origin']
        sender = m['sender']
        sequence = m['sequence']
        topology_update = m['topology']

        if origin in self.processed_messages and self.processed_messages[origin] >= sequence:
            return 


        self.processed_messages[origin] = sequence

        for node_id, neighbors in topology_update.items():
            if not neighbors:
                self.topology.pop(node_id, None)

                for n in self.topology:
                    self.topology[n].pop(node_id, None)
            else:
                self.topology[node_id] = neighbors


        self.calculate_dijkstra()


        for neighbor in self.neighbors:
            if neighbor != sender:
                forward_message = m.copy()
                forward_message['sender'] = self.id
                self.send_to_neighbor(neighbor=neighbor, message=forward_message)

    def get_next_hop(self, destination):
        return self.routes.get(destination, -1)

    def calculate_dijkstra(self):

        graph = {}
        for node, neighbors in self.topology.items():
            if node not in graph:
                graph[node] = {}
            for neighbor, latency in neighbors.items():
                if neighbor not in graph:
                    graph[neighbor] = {}
                graph[node][neighbor] = latency
                graph[neighbor][node] = latency 

        distances = {self.id: 0}
        previous_nodes = {}
        unvisited_nodes = set(graph.keys())

        while unvisited_nodes:

            current_node = min(
                (node for node in unvisited_nodes if node in distances),
                key=lambda node: distances[node],
                default=None
            )
            if current_node is None:
                break

            unvisited_nodes.remove(current_node)

            for neighbor, latency in graph.get(current_node, {}).items():
                new_distance = distances[current_node] + latency
                if neighbor not in distances or new_distance < distances[neighbor]:
                    distances[neighbor] = new_distance
                    previous_nodes[neighbor] = current_node


        self.routes = {}
        for destination in distances:
            if destination == self.id:
                continue
            next_hop = destination
            while previous_nodes.get(next_hop) != self.id:
                next_hop = previous_nodes.get(next_hop)
                if next_hop is None:
                    break
            if next_hop is not None:
                self.routes[destination] = next_hop

    def send_to_neighbors(self, message):
        for neighbor in self.neighbors:
            self.send_to_neighbor(neighbor=neighbor, message=message)
