//! This module defines the layout of a block.
//! 
//! You do not need to modify this file, except for the `default_difficulty` function.
//! Please read this file to understand the structure of a block.

use serde::{Serialize, Deserialize}; //imports to allow serializing and deserializing
use crate::crypto::hash::{H256, Hashable}; // import allowing obejects to be hashed and H256 is the type alias
use crate::transaction::Transaction; // import the transaction struct created in part 1

/// The block header
#[derive(Serialize, Deserialize, Debug, Clone)] //header can be serialized, deserialized, and cloned
pub struct Header {
    pub parent: H256, //each header points to its parents hash
    pub nonce: u32, // the nonce is the number the miner inputed to mine the block (it was below the difficulty)
    pub difficulty: H256, // the block difficulty (data hashed with nonce must be below this value)
    pub timestamp: u128, // time that the block was created
    pub merkle_root: H256, // the merkle root of the block, summary of all the transactions inside
}

/// Transactions contained in a block
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Content {                  //the contents of the block is just a vector of transaction structs
    pub transactions: Vec<Transaction>,
}

/// A block in the blockchain
#[derive(Serialize, Deserialize, Debug, Clone)] // each block contains a header and its list of transactions
pub struct Block {
    pub header: Header,
    pub content: Content,
}

/// Returns the default difficulty, which is a big-endian 32-byte integer.
/// - Note: a valid block must satisfy that `block.hash() <= difficulty`.
///   In other words, the _smaller_ the `difficulty`, the harder it actually is to mine a block!
fn default_difficulty() -> [u8; 32] {
    
    let mut difficulty = [0xff; 32]; //begin by setting the value to all 1
    
    difficulty[0] = 0x00; //make the first byte 0
    
    difficulty[1] = 0x0f; //make the second byte half 0
    
    difficulty //return the rest
}

impl Block {
    /// Construct the (totally deterministic) genesis block
    pub fn genesis() -> Block {
        let transactions: Vec<Transaction> = vec![];
        let header = Header {
            parent: Default::default(),
            nonce: 0,
            difficulty: default_difficulty().into(),
            timestamp: 0,
            merkle_root: Default::default(),
        };
        let content = Content { transactions };
        Block { header, content }
    }
}

impl Hashable for Header {                                  // allows the block header to be hashed
    /// Hash the block header using SHA256.
    fn hash(&self) -> H256 {
        let bytes = bincode::serialize(&self).unwrap();
        ring::digest::digest(&ring::digest::SHA256, &bytes).into()
    }
}

impl Hashable for Block {
    /// Hash only the block header.
    fn hash(&self) -> H256 {
        self.header.hash()
    }
}

/* Please add the following code snippet into `src/transaction.rs`: */
// impl Hashable for Transaction {
//     fn hash(&self) -> H256 {
//         let bytes = bincode::serialize(&self).unwrap();
//         ring::digest::digest(&ring::digest::SHA256, &bytes).into()
//     }
// }

#[cfg(any(test, test_utilities))]
pub mod test {
    use super::*;
    use crate::crypto::hash::H256;
    use crate::crypto::merkle::MerkleTree;

    pub fn generate_random_block(parent: &H256) -> Block {
        let transactions: Vec<Transaction> = vec![Default::default()];
        let root = MerkleTree::new(&transactions).root();
        let header = Header {
            parent: *parent,
            nonce: rand::random(),
            difficulty: default_difficulty().into(),
            timestamp: rand::random(),
            merkle_root: root,
        };
        let content = Content { transactions };
        Block { header, content }
    }
}
