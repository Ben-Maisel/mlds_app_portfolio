library(shiny)
library(bslib)
library(tidyverse)

cdc <- read_delim(file = "cdc.txt", delim = "|") %>%
  mutate(
    genhlth = factor(genhlth, levels = c("excellent", "very good", "good", "fair", "poor")),
    gender = factor(gender, levels = c("f", "m"), labels = c("Female", "Male")),
    hlthplan = factor(hlthplan, levels = c(1, 0), labels = c("Yes", "No")),
    exerany = factor(exerany, levels = c(1, 0), labels = c("Yes", "No")),
    smoke100 = factor(smoke100, levels = c(1, 0), labels = c("Yes", "No"))
  )

ui <- page_sidebar(
  title = "CDC BRFSS Histograms",
  sidebar = sidebar(
    position = "right",
    selectInput(
      inputId = "variable",
      label = "Select Variable:",
      choices = c("Actual Weight" = "weight", "Desired Weight" = "wtdesire", "Height" = "height")
    ),
    sliderInput(
      inputId = "bins",
      label = "Number of bins:",
      min = 5,
      max = 50,
      value = 30
    ),
    radioButtons(
      inputId = "fill_var",
      label = "Select Fill/Legend Variable:",
      choices = c("General Health" = "genhlth", "Health Coverage" = "hlthplan", 
                  "Exercised This Month" = "exerany", "Smoked 100 Cigarettes" = "smoke100", 
                  "Gender" = "gender"),
      selected = "gender"
    )
  ),
  plotOutput(outputId = "distPlot")
)

server <- function(input, output) {
  legend_titles <- list(
    genhlth = "General Health",
    hlthplan = "Health Coverage",
    exerany = "Exercised This Month",
    smoke100 = "Smoked 100 Cigarettes",
    gender = "Gender"
  )
  
  output$distPlot <- renderPlot({
    x_label <- switch(input$variable,
                      "weight" = "Actual Weight in Pounds",
                      "wtdesire" = "Desired Weight in Pounds",
                      "height" = "Height in Inches")
    
    legend_title <- legend_titles[[input$fill_var]]
    
    ggplot(data = cdc, aes_string(x = input$variable, fill = input$fill_var)) +
      geom_histogram(bins = input$bins, color = "black", alpha = 0.7) +
      labs(
        x = x_label,
        y = "Count",
        fill = legend_title
      ) +
      theme_minimal() +
      theme(
        legend.position = "top",
        legend.title = element_text(hjust = 0.5),
        legend.box = "vertical"
      ) +
      guides(fill = guide_legend(title.position = "top", title.hjust = 0.5))
  })
}

shinyApp(ui = ui, server = server)
