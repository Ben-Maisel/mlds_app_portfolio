from lossy_socket import LossyUDP
from socket import INADDR_ANY
from concurrent.futures import ThreadPoolExecutor
import time
from threading import Lock, Event
import hashlib

class CompletePacket:
    def __init__(self, sq_num, data, checksum=None, ack=0):
        self.sq_num = sq_num
        self.data = data
        self.ack = ack
        # Compute checksum based on header (sq_num, ack) and data
        self.checksum = checksum if checksum else self.calculate_checksum()

    def calculate_checksum(self):
        # Combine header fields and data for checksum calculation
        header = self.sq_num.to_bytes(4, 'big') + self.ack.to_bytes(1, 'big')
        return hashlib.md5(header + self.data).digest()

    def to_bytes(self):
        return (self.sq_num.to_bytes(4, 'big') + self.ack.to_bytes(1, 'big') +
                self.checksum + self.data)

    @classmethod
    def from_bytes(cls, packet_bytes):
        sq_num = int.from_bytes(packet_bytes[:4], 'big')
        ack = int.from_bytes(packet_bytes[4:5], 'big')
        checksum = packet_bytes[5:21]
        data = packet_bytes[21:]
        packet = cls(sq_num, data, checksum, ack)
        return packet

    def is_valid(self):
        # Recompute the checksum and compare it to the provided checksum
        return self.checksum == self.calculate_checksum()


class Streamer:
    
    def __init__(self, dst_ip, dst_port, src_ip=INADDR_ANY, src_port=0):
        print("Initializing Streamer...")
        self.socket = LossyUDP()
        self.socket.bind((src_ip, src_port))
        self.dst_ip, self.dst_port = dst_ip, dst_port
        self.next_expected_seq_num = 0
        self.last_sent_seq_num = 0
        self.buffer = {}
        self.window = {} 
        self.collected_data = []
        self.lock = Lock()
        self.closed = False
        self.fin_sent = False
        self.fin_received = False
        self.fin_ack_received = False
        # self.sent_sequences = set()
        self.close_started = False

        # Start listener and retransmission threads
        self.executor = ThreadPoolExecutor(max_workers=2)
        self.executor.submit(self.listener)
        self.executor.submit(self.retransmit_thread)

    def listener(self):
        print("Listener thread started.")
        # set timeout
        self.socket.settimeout(0.25)
        # if not closed
        while not self.closed:
            print("looping")
            try:
                # get data
                data, addr = self.socket.recvfrom()
                # check again if closed
                if self.closed:
                    print("Listener: Streamer is closed, exiting listener.")
                    break

                # make a packet from the data
                packet = CompletePacket.from_bytes(data)
                # discard it if the checksum is wrong
                if not packet.is_valid():
                    print("Listener: Corrupted packet detected (header or data), ignoring.")
                    continue

                # lock    
                with self.lock:
                    # get sq num and ack flag
                    seq_num, ack = packet.sq_num, packet.ack
                    if ack == 1:
                        # If an acknowledgment packet is received, remove from window
                        print(f"Listener: ACK received for packet {seq_num}.")
                        if seq_num in self.window:
                            del self.window[seq_num]
                            print(f"Removed packet {seq_num} from window.")
                        # self.sent_sequences.add(seq_num)
                        continue  # Continue listening for other packets       
                    # if fin packet
                    elif packet.data == b'FIN':
                        print("Listener: Received FIN packet.")
                        if not self.fin_sent:
                            # Respond with FIN-ACK if we haven’t sent our own FIN
                            fin_ack_packet = CompletePacket(seq_num + 1, b'FIN_ACK', ack=2)
                            self.socket.sendto(fin_ack_packet.to_bytes(), addr)
                            print("Listener: Sent FIN-ACK in response to FIN.")
                            self.fin_received = True
                            self.fin_ack_received = True
                            self.closed = True
                            # self.close()
                            break
                        else:
                            # If we've sent our own FIN, acknowledge and close
                            fin_ack_packet = CompletePacket(seq_num + 1, b'FIN_ACK', ack=2)
                            self.socket.sendto(fin_ack_packet.to_bytes(), addr)
                            print("Listener: Both FIN received and sent, closing.")
                            self.closed = True
                            self.fin_received = True
                            break
                    elif packet.data == b'FIN_ACK' and self.fin_sent:
                        print("Listener: Received FIN-ACK, closing connection.")
                        self.fin_ack_received = True
                        self.closed = True
                    # if this is the next packet we are expecting
                    elif seq_num == self.next_expected_seq_num:
                        print(f"Received expected packet {seq_num}.")
                        # add it to our collected data
                        self.collected_data.append(packet.data)
                        # send an ack
                        ack_packet = CompletePacket(seq_num, b'', ack=1)
                        self.socket.sendto(ack_packet.to_bytes(), addr)
                        print(f"Listener: Sent ACK for packet {seq_num}.")
                        # we are now expecting the next packet so increment
                        self.next_expected_seq_num +=1
                        # now pull from buffer
                        while self.next_expected_seq_num in self.buffer:
                            self.collected_data.append(self.buffer.pop(self.next_expected_seq_num))
                            self.next_expected_seq_num +=1
                    # if we got a packet with a higher sq num than expected, buffer it
                    elif seq_num > self.next_expected_seq_num and seq_num not in self.buffer:
                            self.buffer[seq_num] = packet.data
                            print(f"Listener: Received data packet {seq_num}.")
                            # send an ack
                            ack_packet = CompletePacket(seq_num, b'', ack=1)
                            self.socket.sendto(ack_packet.to_bytes(), addr)
                            print(f"Listener: Sent ACK for packet {seq_num}.")

            except TimeoutError:
                if self.closed:
                    print("Listener: Timeout after closure, exiting.")
                    break

    def send(self, data_bytes: bytes):
        print("Starting send operation.")
        # partition the data into packets and set a flag that not all has been sent
        cap = 1451
        if len(data_bytes) <= cap:
            num_packets = 1
        else:  
            num_packets = (len(data_bytes) + cap - 1) // cap

        packet_num = 0

        while packet_num < num_packets:
            with self.lock:
                # if self.last_sent_seq_num in self.sent_sequences:
                #     print(f"Skipping already acknowledged packet {self.last_sent_seq_num}")
                #     packet_num += 1
                #     self.last_sent_seq_num += 1
                #     continue

                packet_data = data_bytes[packet_num * cap: (packet_num + 1) * cap]
                packet = CompletePacket(self.last_sent_seq_num, packet_data)
                packet_bytes = packet.to_bytes()
                if self.last_sent_seq_num not in self.window:
                    self.window[self.last_sent_seq_num] = (packet_bytes, time.time(), 0)
                print(f"Adding packet {self.last_sent_seq_num} to window for tracking.")
                self.socket.sendto(packet_bytes, (self.dst_ip, self.dst_port))
                print(f"Sent packet {self.last_sent_seq_num}")
                # self.sent_sequences.add(self.last_sent_seq_num)
                self.last_sent_seq_num += 1
                packet_num += 1

    def retransmit_thread(self):
        while not self.closed:
            with self.lock:
                current_time = time.time()
                for seq_num, (packet_bytes, timestamp, retries) in list(self.window.items()):
                    if retries == 5:
                        del self.window[seq_num]
                    if current_time - timestamp > 0.25:
                        print(f"Retransmitting packet {seq_num} due to timeout.")
                        self.socket.sendto(packet_bytes, (self.dst_ip, self.dst_port))
                        self.window[seq_num] = (packet_bytes, current_time, retries+1)
                        print("Window: ", self.window.keys())
            time.sleep(0.25)

    def recv(self) -> bytes:
        print("Starting receive operation.")
        collected_data = []
        while True:
            with self.lock:
                if self.collected_data:
                    collected_data.append(b''.join(self.collected_data))
                    print("recv: Data collected.")
                    self.collected_data.clear()
            if collected_data:
                print("recv: Returning collected data.")
                return b''.join(collected_data)
            time.sleep(0.01)

    def close(self):
        print("Starting close operation.")
        MAX_RETRIES = 3
        window_retries = 0
        while self.window and window_retries < MAX_RETRIES:
            print("Window: ", self.window.keys())
            window_retries +=1
            time.sleep(0.25)
        fin_packet = CompletePacket(self.last_sent_seq_num, b'FIN')
        self.fin_sent = True  # Mark FIN as sent

        
        retries = 0

        # Loop to wait for FIN-ACK or detect that FIN has been received
        while not self.fin_ack_received and not self.fin_received and retries < MAX_RETRIES:
            # If we've received a FIN from the other host, stop waiting and close
            if self.fin_received:
                print("close: FIN received from peer, no need to wait for FIN-ACK.")
                break
            
            # Send FIN packet if still awaiting response
            self.socket.sendto(fin_packet.to_bytes(), (self.dst_ip, self.dst_port))
            print("close: Sent FIN packet, waiting for FIN-ACK or FIN from peer.")
            retries +=1
            time.sleep(0.25)

        # Close connection and shutdown listener
        print("close: FIN-ACK received or FIN from peer, closing connection.")
        self.window = {}
        self.closed = True
        self.executor.shutdown(wait=False)
        self.socket.stoprecv()
        
        print("Connection closed.")
