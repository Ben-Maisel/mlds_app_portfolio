// get request to return information about the cabins from our sql database

const dbConnection = require('./database.js')                    //we need this import to access amazon and our sql database
const { cabins, activities, units, otherValidActivities } = require('./data.js')

exports.get_cabins = async (req, res) => {         // this is our async function that will be called with the extension '/get_cabins'. We export it so we can use it in index.js

  console.log("call to /get_cabins...") // lets us know we are calling this function

  try{
    var sql = `      
      SELECT * 
      FROM cabins
      ORDER BY cabinid ASC;
    `;                     //the sql query we want to execute

    const rds_response = await new Promise((resolve, reject) => {  // create a variable that will wait for our rds query and store the response
      console.log("/get_cabins: calling RDS...");

      dbConnection.query(sql, (err, results) => { //execute our sql query (we must use a call back function for this)
        if (err) {
          return reject(err); //this will cause the promise to be rejected if there is an error
        }
        resolve(results); //if there is no error, resolve the results to fullfill the promise
      });
    });

    console.log('query complete, responding with results...')

    res.status(200).json({
      "message" : "success",
      "data" : rds_response
    });
    
    
  } catch (err) {
    console.log("**ERROR:", err.message);


    res.status(400).json({
      "message": err.message
    });
  }
};