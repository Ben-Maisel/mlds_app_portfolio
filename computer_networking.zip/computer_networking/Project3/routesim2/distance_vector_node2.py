from simulator.node import Node

class Distance_Vector_Node(Node):
    def __init__(self, id):
        super().__init__(id)
        self.id = id
        self.neighbors = {}  # neighbor_id: latency
        self.distance_vector = {}  # dest_id: {'cost': cost, 'next_hop': next_hop, 'path': [path]}
        self.neighbor_distance_vectors = {}  # neighbor_id: {'timestamp': timestamp, 'distances': {}, 'paths': {}}

        # Initialize distance to self
        self.distance_vector[self.id] = {'cost': 0, 'next_hop': self.id, 'path': [self.id]}
        self.send_distance_vector()

    def __str__(self):
        return f"Node {self.id}: Distance Vector: {self.distance_vector}"

    def link_has_been_updated(self, neighbor, latency):
        if latency == -1:
            # Link removed
            if neighbor in self.neighbors:
                del self.neighbors[neighbor]
                if neighbor in self.neighbor_distance_vectors:
                    del self.neighbor_distance_vectors[neighbor]

                # Invalidate all routes using the deleted neighbor
                routes_changed = False
                for dest in list(self.distance_vector.keys()):
                    if self.distance_vector[dest]['next_hop'] == neighbor:
                        del self.distance_vector[dest]
                        routes_changed = True

                # Aggressively recompute distance vector for all destinations
                updated = self.recompute_distance_vector()
                # Send updated distance vector if any changes occurred
                if updated or routes_changed:
                    self.send_distance_vector()

        else:
            # Link added or updated
            self.neighbors[neighbor] = latency
            if neighbor not in self.neighbor_distance_vectors:
                self.neighbor_distance_vectors[neighbor] = {
                    'timestamp': -1,
                    'distances': {},
                    'paths': {}
                }
            self.distance_vector[neighbor] = {
                'cost': latency,
                'next_hop': neighbor,
                'path': [self.id, neighbor]
            }
            updated = self.recompute_distance_vector()
            if updated:
                self.send_distance_vector()


    def send_distance_vector(self):
        for neighbor in self.neighbors:
            dv_to_send = {}
            paths_to_send = {}
            for dest_id, info in self.distance_vector.items():
                if info['next_hop'] == neighbor and dest_id != neighbor:
                    continue
                dv_to_send[dest_id] = info['cost']
                paths_to_send[dest_id] = info['path'][:]
            message = {
                'sender': self.id,
                'timestamp': self.get_time(),
                'distances': dv_to_send,
                'paths': paths_to_send
            }
            self.send_to_neighbor(neighbor, message)

    def process_incoming_routing_message(self, m):
        sender = m['sender']
        if sender not in self.neighbors:
            return
        if m['timestamp'] <= self.neighbor_distance_vectors[sender]['timestamp']:
            return
        self.neighbor_distance_vectors[sender] = {
            'timestamp': m['timestamp'],
            'distances': m['distances'],
            'paths': m['paths']
        }
        #print({self.id}, {self.distance_vector})
        updated = self.recompute_distance_vector()
        if updated:
            self.send_distance_vector()

    def recompute_distance_vector(self):
        updated = False
        all_dests = set(self.distance_vector.keys()) | {
            dest
            for neighbor_info in self.neighbor_distance_vectors.values()
            for dest in neighbor_info.get('distances', {})
        }

        for dest_id in all_dests:
            #print(f"Updated path to destination {dest_id}: cost={min_cost}, next_hop={next_hop}, path={min_path}")
            if dest_id == self.id:
                continue

            min_cost = float('inf')
            next_hop = None
            min_path = []

            for neighbor in self.neighbors:
                cost_to_neighbor = self.neighbors[neighbor]
                neighbor_info = self.neighbor_distance_vectors.get(neighbor, {})
                neighbor_distances = neighbor_info.get('distances', {})
                neighbor_paths = neighbor_info.get('paths', {})
                neighbor_timestamp = neighbor_info.get('timestamp', 0)

                neighbor_cost_to_dest = neighbor_distances.get(dest_id, float('inf'))
                neighbor_path_to_dest = neighbor_paths.get(dest_id, [])

                # Ignore unreachable destinations or paths that would form a loop
                if neighbor_cost_to_dest == float('inf'):
                    continue
                if self.id in neighbor_path_to_dest:
                    continue

                # Compute total cost
                total_cost = cost_to_neighbor + neighbor_cost_to_dest

                # Update if this is the best path found so far
                if total_cost < min_cost:
                    min_cost = total_cost
                    next_hop = neighbor
                    min_path = [self.id] + neighbor_path_to_dest

            # Update distance vector if necessary
            if dest_id not in self.distance_vector or \
                    self.distance_vector[dest_id]['cost'] != min_cost or \
                    self.distance_vector[dest_id]['next_hop'] != next_hop:

                if min_cost == float('inf'):
                    # Remove unreachable destination
                    if dest_id in self.distance_vector:
                        del self.distance_vector[dest_id]
                else:
                    # Update distance vector with the new best path
                    self.distance_vector[dest_id] = {
                        'cost': min_cost,
                        'next_hop': next_hop,
                        'path': min_path
                    }
                

                updated = True

        return updated

    def get_next_hop(self, destination):
        if destination in self.distance_vector and \
                self.distance_vector[destination]['cost'] != float('inf'):
            return self.distance_vector[destination]['next_hop']
        else:
            return -1
