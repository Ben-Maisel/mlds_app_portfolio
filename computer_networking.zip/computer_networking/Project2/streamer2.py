from lossy_socket import LossyUDP
from socket import INADDR_ANY
from concurrent.futures import ThreadPoolExecutor
import time
from threading import RLock, Timer
import hashlib

class CompletePacket:
    def __init__(self, sq_num, data, checksum=None, ack=0, ack_num=0):
        self.sq_num = sq_num
        self.data = data
        self.ack = ack
        self.ack_num = ack_num
        # Compute checksum based on header (sq_num, ack, ack_num) and data
        self.checksum = checksum if checksum else self.calculate_checksum()

    def calculate_checksum(self):
        # Combine header fields and data for checksum calculation
        header = (
            self.sq_num.to_bytes(4, 'big') +
            self.ack.to_bytes(1, 'big') +
            self.ack_num.to_bytes(4, 'big')
        )
        return hashlib.md5(header + self.data).digest()

    def to_bytes(self):
        return (
            self.sq_num.to_bytes(4, 'big') +
            self.ack.to_bytes(1, 'big') +
            self.ack_num.to_bytes(4, 'big') +
            self.checksum +
            self.data
        )

    @classmethod
    def from_bytes(cls, packet_bytes):
        sq_num = int.from_bytes(packet_bytes[:4], 'big')
        ack = int.from_bytes(packet_bytes[4:5], 'big')
        ack_num = int.from_bytes(packet_bytes[5:9], 'big')
        checksum = packet_bytes[9:25]
        data = packet_bytes[25:]
        packet = cls(sq_num, data, checksum, ack, ack_num)
        return packet

    def is_valid(self):
        # Recompute the checksum and compare it to the provided checksum
        return self.checksum == self.calculate_checksum()


class Streamer:

    def __init__(self, dst_ip, dst_port, src_ip=INADDR_ANY, src_port=0):
        print("Initializing Streamer...")
        self.socket = LossyUDP()
        self.socket.bind((src_ip, src_port))
        self.dst_ip, self.dst_port = dst_ip, dst_port
        self.next_expected_seq_num = 0
        self.last_sent_seq_num = 0
        self.buffer = {}
        self.window = {}
        self.collected_data = []
        self.lock = RLock()
        self.closed = False
        self.fin_sent = False
        self.fin_received = False
        self.fin_ack_received = False
        self.close_started = False

        # Nagle's algorithm variables
        self.send_buffer = bytearray()
        header_size = 4 + 1 + 4 + 16  # sq_num + ack + ack_num + checksum
        self.max_packet_size = 1472 - header_size  # 1447 bytes
        self.max_window_size = 10  # Maximum number of unacknowledged packets

        # Send timer variables
        self.send_timer = None
        self.send_delay = 0.2  # 200 ms delay

        # Delayed ACK variables
        self.ack_timer = None
        self.pending_ack_seq_num = None
        self.ack_delay = 0.2  # 200 ms delay

        # Start listener and retransmission threads
        self.executor = ThreadPoolExecutor(max_workers=2)
        self.executor.submit(self.listener)
        self.executor.submit(self.retransmit_thread)

    def schedule_ack(self, seq_num):
        self.pending_ack_seq_num = seq_num
        if self.ack_timer is None or not self.ack_timer.is_alive():
            self.ack_timer = Timer(self.ack_delay, self.send_ack)
            self.ack_timer.start()

    def send_ack(self):
        with self.lock:
            if self.pending_ack_seq_num is not None:
                # Create a pure ACK packet
                ack_packet = CompletePacket(0, b'', ack=1, ack_num=self.pending_ack_seq_num)
                self.socket.sendto(ack_packet.to_bytes(), (self.dst_ip, self.dst_port))
                print(f"Listener: Sent delayed ACK for packet {self.pending_ack_seq_num}.")
                self.pending_ack_seq_num = None
                self.ack_timer = None

    def flush_send_buffer(self):
        with self.lock:
            if self.send_buffer:
                print("Flush send buffer timer triggered, sending data.")
                self.send_timer = None
                self.process_send_buffer()

    def process_send_buffer(self):
        with self.lock:
            while self.send_buffer and (
                len(self.send_buffer) >= self.max_packet_size or
                not self.window or
                not self.send_timer or
                len(self.window) < self.max_window_size
            ):
                packet_data = self.send_buffer[:self.max_packet_size]
                self.send_buffer = self.send_buffer[self.max_packet_size:]

                ack_num = self.pending_ack_seq_num if self.pending_ack_seq_num is not None else 0
                packet = CompletePacket(self.last_sent_seq_num, packet_data, ack=0, ack_num=ack_num)
                packet_bytes = packet.to_bytes()

                if len(packet_bytes) > 1472:
                    raise RuntimeError(f"Packet size {len(packet_bytes)} exceeds maximum allowed size.")

                self.window[self.last_sent_seq_num] = (packet_bytes, time.time())
                print(f"Adding packet {self.last_sent_seq_num} to window for tracking.")
                self.socket.sendto(packet_bytes, (self.dst_ip, self.dst_port))
                print(f"Sent packet {self.last_sent_seq_num}")

                if ack_num != 0:
                    print(f"Sent piggybacked ACK for packet {ack_num}")
                    self.pending_ack_seq_num = None
                    if self.ack_timer is not None:
                        self.ack_timer.cancel()
                        self.ack_timer = None

                self.last_sent_seq_num += 1

            if not self.send_buffer and self.send_timer:
                self.send_timer.cancel()
                self.send_timer = None

    def listener(self):
        print("Listener thread started.")
        # set timeout
        self.socket.settimeout(0.25)
        # if not closed
        while not self.closed:
            try:
                # get data
                data, addr = self.socket.recvfrom()
                # check again if closed
                if self.closed:
                    print("Listener: Streamer is closed, exiting listener.")
                    break

                # make a packet from the data
                packet = CompletePacket.from_bytes(data)
                # discard it if the checksum is wrong
                if not packet.is_valid():
                    print("Listener: Corrupted packet detected (header or data), ignoring.")
                    continue

                # lock
                with self.lock:
                    seq_num, ack = packet.sq_num, packet.ack
                    ack_num = packet.ack_num

                    if ack_num != 0:
                        print(f"Listener: Piggybacked ACK received for packet {ack_num}.")
                        if ack_num in self.window:
                            del self.window[ack_num]
                            print(f"Removed packet {ack_num} from window.")
                            # Process send buffer if window is empty
                            if not self.window and self.send_buffer:
                                print("Window is empty and send buffer has data, processing send buffer.")
                                self.process_send_buffer()

                    if ack == 1:
                        # Pure ACK packet received
                        print(f"Listener: ACK received for packet {packet.ack_num}.")
                        if packet.ack_num in self.window:
                            del self.window[packet.ack_num]
                            print(f"Removed packet {packet.ack_num} from window.")
                            # Process send buffer if window is empty
                            if not self.window and self.send_buffer:
                                print("Window is empty and send buffer has data, processing send buffer.")
                                self.process_send_buffer()
                        continue  # Continue listening for other packets

                    # if fin packet
                    elif packet.data == b'FIN':
                        print("Listener: Received FIN packet.")
                        if not self.fin_sent:
                            # Respond with FIN-ACK if we haven’t sent our own FIN
                            fin_ack_packet = CompletePacket(seq_num + 1, b'FIN_ACK', ack=2)
                            self.socket.sendto(fin_ack_packet.to_bytes(), addr)
                            print("Listener: Sent FIN-ACK in response to FIN.")
                            self.fin_received = True
                            self.fin_ack_received = True
                            self.closed = True
                            break
                        else:
                            # If we've sent our own FIN, acknowledge and close
                            fin_ack_packet = CompletePacket(seq_num + 1, b'FIN_ACK', ack=2)
                            self.socket.sendto(fin_ack_packet.to_bytes(), addr)
                            print("Listener: Both FIN received and sent, closing.")
                            self.closed = True
                            self.fin_received = True
                            break
                    elif packet.data == b'FIN_ACK' and self.fin_sent:
                        print("Listener: Received FIN-ACK, closing connection.")
                        self.fin_ack_received = True
                        self.closed = True
                    else:
                        # Data packet received
                        if seq_num == self.next_expected_seq_num:
                            print(f"Received expected packet {seq_num}.")
                            # add it to our collected data
                            self.collected_data.append(packet.data)
                            self.next_expected_seq_num += 1
                            # now pull from buffer
                            while self.next_expected_seq_num in self.buffer:
                                self.collected_data.append(self.buffer.pop(self.next_expected_seq_num))
                                self.next_expected_seq_num += 1
                            # Schedule a delayed ACK
                            self.schedule_ack(seq_num)
                        elif seq_num > self.next_expected_seq_num and seq_num not in self.buffer:
                            self.buffer[seq_num] = packet.data
                            print(f"Listener: Buffered out-of-order packet {seq_num}.")
                            # Schedule a delayed ACK
                            self.schedule_ack(seq_num)
            except TimeoutError:
                if self.closed:
                    print("Listener: Timeout after closure, exiting.")
                    break

    def send(self, data_bytes: bytes):
        print("Starting send operation.")
        with self.lock:
            self.send_buffer += data_bytes  # Append data to the send buffer

            if not self.send_timer or not self.send_timer.is_alive():
                self.send_timer = Timer(self.send_delay, self.flush_send_buffer)
                self.send_timer.start()

            self.process_send_buffer()  # Process the send buffer

    def retransmit_thread(self):
        while not self.closed:
            with self.lock:
                current_time = time.time()
                for seq_num, (packet_bytes, timestamp) in list(self.window.items()):
                    if current_time - timestamp > 0.25:
                        print(f"Retransmitting packet {seq_num} due to timeout.")
                        self.socket.sendto(packet_bytes, (self.dst_ip, self.dst_port))
                        self.window[seq_num] = (packet_bytes, current_time)
            time.sleep(0.25)

    def recv(self) -> bytes:
        print("Starting receive operation.")
        collected_data = []
        while True:
            with self.lock:
                if self.collected_data:
                    collected_data.append(b''.join(self.collected_data))
                    print("recv: Data collected.")
                    self.collected_data.clear()
            if collected_data:
                print("recv: Returning collected data.")
                return b''.join(collected_data)
            time.sleep(0.01)

    def close(self):
        print("Starting close operation.")
        MAX_RETRIES = 3
        window_retries = 0
        while self.window and window_retries < MAX_RETRIES:
            print("Waiting for window to clear. Window: ", self.window.keys())
            window_retries += 1
            time.sleep(0.25)
        fin_packet = CompletePacket(self.last_sent_seq_num, b'FIN')
        self.fin_sent = True  # Mark FIN as sent

        retries = 0

        # Loop to wait for FIN-ACK or detect that FIN has been received
        while not self.fin_ack_received and not self.fin_received and retries < MAX_RETRIES:
            # If we've received a FIN from the other host, stop waiting and close
            if self.fin_received:
                print("close: FIN received from peer, no need to wait for FIN-ACK.")
                break

            # Send FIN packet if still awaiting response
            self.socket.sendto(fin_packet.to_bytes(), (self.dst_ip, self.dst_port))
            print("close: Sent FIN packet, waiting for FIN-ACK or FIN from peer.")
            retries += 1
            time.sleep(0.25)

        # Close connection and shutdown listener
        print("close: FIN-ACK received or FIN from peer, closing connection.")
        self.window = {}
        self.closed = True
        self.executor.shutdown(wait=False)
        self.socket.stoprecv()

        print("Connection closed.")
