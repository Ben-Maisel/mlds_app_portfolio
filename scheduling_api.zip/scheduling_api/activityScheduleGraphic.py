from PIL import Image, ImageDraw, ImageFont

def create_schedule_image(schedule, activity_name): # helper function to make the schedule image
    
    square_width, square_height = 100, 165 # size of each sqaure, represent a period on the image
    offset_width, offset_height = 100, 50  # offset start so we have room to draw in the indices
    image_width, image_height = square_width * 5 + offset_width, square_height * 8 + offset_height # total image size

    
    image = Image.new('RGB', (image_width, image_height), color='white') # creates a new image with a white background
    draw = ImageDraw.Draw(image)

    try:
        font = ImageFont.truetype("arial.ttf", 15) # try to select a font, if not, just use the default
    except IOError:
        font = ImageFont.load_default()

    
    activity_text = f"Activity: {activity_name}"
    draw.text((10, 10), activity_text, fill='black', font=font) # write the cabin name on the image first

    # Draw the period indices on top
    for period in range(1, 5):
        period_text = f"Period {period}"
        x = offset_width + (period - 1) * square_width + square_width // 2 # format the period index text and then draw it in
        draw.text((x, 10), period_text, fill='black', font=font, anchor="mm")

    # Draw days and cabinlists
    for day_index, day in enumerate(schedule['days']):  # Iterate over each day
        day_text = f"Day {day_index + 1}"
        y = 5 + offset_height + day_index * square_height + square_height // 2
        draw.text((10, y), day_text, fill='black', font=font)

        for period_index, cabinlist in enumerate(day['periods']):  # Iterate over each period
            x0 = offset_width + period_index * square_width
            y0 = offset_height + day_index * square_height
            x1 = x0 + square_width
            y1 = y0 + square_height

            draw.rectangle([x0, y0, x1, y1], outline='black') # draw the cell in

            # Draw cabin list
            cabinlist = '\n'.join(cabinlist)
            w, h = draw.textsize(cabinlist, font=font) #write the text in the centre of the cell
            draw.text((x0 + (square_width - w)/2, y0 + (square_height - h)/2), cabinlist, fill='black', font=font)

    # Save and display the image
    image_file = f'{activity_name}_current_schedule.png'
    image.save(image_file) # save the image and display it
    image.show()

    return image_file

#-------------------------------------------------------------------------------------------------------------------------

def create_pastschedule_image(schedule, schedule_date, activity_name): # helper function to make the schedule image
    
    square_width, square_height = 100, 165 # size of each sqaure, represent a period on the image
    offset_width, offset_height = 100, 50  # offset start so we have room to draw in the indices
    image_width, image_height = square_width * 5 + offset_width, square_height * 8 + offset_height # total image size

    
    image = Image.new('RGB', (image_width, image_height), color='white') # creates a new image with a white background
    draw = ImageDraw.Draw(image)

    try:
        font = ImageFont.truetype("arial.ttf", 15) # try to select a font, if not, just use the default
    except IOError:
        font = ImageFont.load_default()

    
    activity_text = f"Activity: {activity_name}\n Date: {schedule_date}"
    draw.text((10, 10), activity_text, fill='black', font=font) # write the cabin name on the image first

    # Draw the period indices on top
    for period in range(1, 5):
        period_text = f"Period {period}"
        x = offset_width + (period - 1) * square_width + square_width // 2 # format the period index text and then draw it in
        draw.text((x, 10), period_text, fill='black', font=font, anchor="mm")

    # Draw days and cabinlists
    for day_index, day in enumerate(schedule['days']):  # Iterate over each day
        day_text = f"Day {day_index + 1}"
        y = 5 + offset_height + day_index * square_height + square_height // 2
        draw.text((10, y), day_text, fill='black', font=font)

        for period_index, cabinlist in enumerate(day['periods']):  # Iterate over each period
            x0 = offset_width + period_index * square_width
            y0 = offset_height + day_index * square_height
            x1 = x0 + square_width
            y1 = y0 + square_height

            draw.rectangle([x0, y0, x1, y1], outline='black') # draw the cell in

            # Draw cabin list
            cabinlist = '\n'.join(cabinlist)
            w, h = draw.textsize(cabinlist, font=font) #write the text in the centre of the cell
            draw.text((x0 + (square_width - w)/2, y0 + (square_height - h)/2), cabinlist, fill='black', font=font)

    # Save and display the image
    image_file = f'{activity_name}_current_schedule.png'
    image.save(image_file) # save the image and display it
    image.show()

    return image_file
