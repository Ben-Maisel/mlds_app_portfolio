//! This module implements the blockchain.
//! 
//! You need to implement the `Blockchain` struct and its methods.

use crate::block::Block;
use crate::crypto::hash::{H256, Hashable};
use std::collections::HashMap;

pub struct Blockchain {
    
    hash_to_block: HashMap<H256, Block>,
    hash_to_height: HashMap<H256, u64>,
    tip: H256,
    genesis_hash: H256,
}

impl Blockchain {
    /// Create a new blockchain, only containing the genesis block
    pub fn new() -> Self {
        
        
        let genesis_block = Block::genesis(); //use the provided method to create the genesis block

        let genesis_hash = genesis_block.hash(); // get the hash of the genesis block
        
        // initialize hash_to_block map and insert genesis
        let mut hash_to_block = HashMap::new(); //create the new map
        hash_to_block.insert(genesis_hash, genesis_block); //put in hash as key and block as value

        // initialize hash_to_height map, genesis is height 0
        let mut hash_to_height = HashMap::new(); //create the new map
        hash_to_height.insert(genesis_hash, 0); //genesis is at height 0

        // initialize tip to genesis
        let tip = genesis_hash;

        Blockchain {
            hash_to_block,
            hash_to_height,
            tip,
            genesis_hash,
        }
    }

    /// Insert a block into blockchain
    pub fn insert(&mut self, block: &Block) {
        
        // first, check if parent is in the hash to block map
        if !self.hash_to_block.contains_key(&block.header.parent) {
            println!("Parent not in chain!");
            return;
        }

        let block_hash = block.hash(); //compute the hash of the new block

        self.hash_to_block.insert(block_hash, block.clone()); //update the hash to block map

        let parent_height = self.hash_to_height.get(&block.header.parent).unwrap_or(&0); //get height of parent block

        self.hash_to_height.insert(block_hash, parent_height + 1); //update hash to height map

        let new_block_height = self.hash_to_height.get(&block_hash).unwrap_or(&0); //get height for comparison purposes

        if new_block_height > self.hash_to_height.get(&self.tip).unwrap_or(&0) { //compare and update tip if longer
            self.tip = block_hash;
        }
    }

    /// Get the last block's hash of the longest chain
    pub fn tip(&self) -> H256 {
        return self.tip;
    }

    /// Get all the blocks' hashes along the longest chain
    #[cfg(any(test, test_utilities))]
    pub fn all_blocks_in_longest_chain(&self) -> Vec<H256> {
        
        let mut hashes: Vec<H256> = Vec::new(); //initialize a vector to store the hashes

        let mut current_hash = self.tip; //initialize current hash for loop

        while current_hash != self.genesis_hash {

            if let Some(current_block) = self.hash_to_block.get(&current_hash) { //if current block is in the map

                hashes.push(current_hash); //add the current hash to the vector

                let parent_block_hash = current_block.header.parent; // get the blocks parent

                current_hash = parent_block_hash; // update current hash

            } else { //return empty vec if block not in map
                
                println!("error! block not in map");
                return Vec::new();
            }

        }

        hashes.push(self.genesis_hash); //finally add genesis hash

        hashes.reverse();

        return hashes;

    }
}


#[cfg(any(test, test_utilities))]
mod tests {
    use super::*;
    use crate::block::test::generate_random_block;

    #[test]
    fn insert_one() {
        let mut blockchain = Blockchain::new();
        let genesis_hash = blockchain.tip();
        let block = generate_random_block(&genesis_hash);
        blockchain.insert(&block);
        assert_eq!(blockchain.tip(), block.hash());
    }

    #[test]
    fn mp1_insert_chain() {
        let mut blockchain = Blockchain::new();
        let genesis_hash = blockchain.tip();
        let mut block = generate_random_block(&genesis_hash);
        blockchain.insert(&block);
        assert_eq!(blockchain.tip(), block.hash());
        for _ in 0..50 {
            let h = block.hash();
            block = generate_random_block(&h);
            blockchain.insert(&block);
            assert_eq!(blockchain.tip(), block.hash());
        }
    }

    #[test]
    fn mp1_insert_3_fork_and_back() {
        let mut blockchain = Blockchain::new();
        let genesis_hash = blockchain.tip();
        let block_1 = generate_random_block(&genesis_hash);
        blockchain.insert(&block_1);
        assert_eq!(blockchain.tip(), block_1.hash());
        let block_2 = generate_random_block(&block_1.hash());
        blockchain.insert(&block_2);
        assert_eq!(blockchain.tip(), block_2.hash());
        let block_3 = generate_random_block(&block_2.hash());
        blockchain.insert(&block_3);
        assert_eq!(blockchain.tip(), block_3.hash());
        let fork_block_1 = generate_random_block(&block_2.hash());
        blockchain.insert(&fork_block_1);
        assert_eq!(blockchain.tip(), block_3.hash());
        let fork_block_2 = generate_random_block(&fork_block_1.hash());
        blockchain.insert(&fork_block_2);
        assert_eq!(blockchain.tip(), fork_block_2.hash());
        let block_4 = generate_random_block(&block_3.hash());
        blockchain.insert(&block_4);
        assert_eq!(blockchain.tip(), fork_block_2.hash());
        let block_5 = generate_random_block(&block_4.hash());
        blockchain.insert(&block_5);
        assert_eq!(blockchain.tip(), block_5.hash());
    }

}
