const dbConnection = require('./database.js')                    //we need this import to access our sql database
const { cabins, activities, units, otherValidActivities } = require('./data.js')
const { Schedule } = require('./class_definitions.js')


function getRandomActivity() {
  const randomIndex = Math.floor(Math.random() * activities.length); //this generates a random numbers that is always within the bounds of our array
  return activities[randomIndex].name; //access the activity at the random index and return its name
}

function initializeActivityEnrollment() { // helper function to create structure to keep track of how many cabins at a period at once
  let enrollment = {};                    //create empty dict
    [...activities, ...otherValidActivities].forEach(activity => {          //for each activity
    enrollment[activity.name] = {};        //the key is the activity name and the value is an empty dict
    for (let day = 0; day < 7; day++) {               //for each day
      enrollment[activity.name][`Day${day}`] = {};   //the day name is the key and the value is an empty dict. this is nested inside the previous value dict attached to activity name
      for (let period = 0; period < 4; period++) {   // for each period, a key is created in the value value dict and the value is set to 0
        enrollment[activity.name][`Day${day}`][`Period${period}`] = 0;
      }
    }
  });

  enrollment['Swim'] = {};
  for (let day = 0; day < 7; day++) {
    enrollment['Swim'][`Day${day}`] = {};
    for (let period = 0; period < 4; period++) {  //manually add swim
      enrollment['Swim'][`Day${day}`][`Period${period}`] = 0;
    }
  }
  return enrollment;
}
/*resulting structure from above function is like so:

{activity name : {day1 : {period1 : 0, ...}, ...}, ...}  

where each activity have 7 days and 4 periods per day
*/

function initializeActivityFrequency() { //helper function to create a structure to keep track of how many times an activity appears in a schedule
  let frequency = {};   //create empty dict
    [...activities, ...otherValidActivities].forEach(activity => {  //each activity name is a key and its value is initialized to 0 (no activities chosen yet)
    frequency[activity.name] = 0
  });
  frequency['Swim'] = 0;
  return frequency;
}

function initializeDailyActivities(){ //helper function to create a structure to keep track of which activities are assigned on which day
  let dailyActivities = {};
  for (let day = 0; day < 7; day++) {
    dailyActivities[`Day${day}`] = [];
  }
  return dailyActivities
}


function activityExists(activity) { //helper function to check whether a requested activity is valid
  return activities.some(a => a.name === activity) || otherValidActivities.some(b => b.name === activity); //make sure the activity exists in either the general list, or other list
} 

function specialtyRequests(cabinName, requests, activityFrequency, activityFrequencyMap) { //helper function to assign specialty requests
  const cabinRequest = requests.find(r => r.cabinName === cabinName);  //find the cabins requests in the reqeusts object. if it does not exist, return null
  if (!cabinRequest) return null;

  const specialtyRequests = cabinRequest.requests.specialtyPeriodRequests; //find the first valid activity in the specialty requests section
  for (let choice in specialtyRequests) {
    let activity = specialtyRequests[choice];
    if (activity && activityExists(activity) && activityFrequency[activity] < activityFrequencyMap.get(activity)) {
      return activity;
    }
  }
  return null;
}
function sportsRequests(cabinName, requests, activityFrequency, activityFrequencyMap) { //helper function to assign sports requests
  const cabinRequest = requests.find(r => r.cabinName === cabinName);  //find the cabins requests in the reqeusts object. if it does not exist, return null
  if (!cabinRequest) return null;

  const sportsRequests = cabinRequest.requests.sportsRequests; //find the first valid activity in the sports requests section
  for (let choice in sportsRequests) {
    let activity = sportsRequests[choice];
    if (activity && activityExists(activity) && activityFrequency[activity] < activityFrequencyMap.get(activity)) {
      return activity;
    }
  }
  return null;
}
function groupChoiceRequests(cabinName, requests, activityFrequency, activityFrequencyMap) { //helper function to assign groupChoice requests
  const cabinRequest = requests.find(r => r.cabinName === cabinName);  //find the cabins requests in the reqeusts object. if it does not exist, return null
  if (!cabinRequest) return null;

  const groupRequests = cabinRequest.requests.groupChoicePeriod; //find the first valid activity in the group choice requests section
  for (let choice in groupRequests) {
    let activity = groupRequests[choice];
    if (activity && activityExists(activity) && activityFrequency[activity] < activityFrequencyMap.get(activity)) {
      return activity;
    }
  }
  return null;
}
function missingPeriodRequests(cabinName, requests, activityFrequency, activityFrequencyMap) { //helper function to assign missing periods requests
  const cabinRequest = requests.find(r => r.cabinName === cabinName);  //find the cabins requests in the reqeusts object. if it does not exist, return null
  if (!cabinRequest) return null;

  const missingRequests = cabinRequest.requests.missedActivities; //find the first valid activity in the missing periods requests section
  for (let choice in missingRequests) {
    let activity = missingRequests[choice];
    if (activity && activityExists(activity) && activityFrequency[activity] < activityFrequencyMap.get(activity)) {
      return activity;
    }
  }
  return null;
}

function isValidActivity(selected_activity, day, period, activityEnrollment, activityFrequency, activityFrequencyMap, activityCapacityMap, dailyActivities) { //helper function to make sure activity can be selected
  return !(activityEnrollment[selected_activity][`Day${day}`][`Period${period}`] >= activityCapacityMap.get(selected_activity) || 
   activityFrequency[selected_activity] >= activityFrequencyMap.get(selected_activity) ||
   dailyActivities[`Day${day}`].includes(selected_activity))
}



// ----------------------------------------------The MEAT of this project------------------------------------------------------------------------------------------------



function assignRandomSchedules(requests) {
  const cabinSchedules = [];
  
  let activitySchedules = {};
    [...activities, ...otherValidActivities].forEach(activity => {                             //generate an empty schedule for each activity
    activitySchedules[activity.name] = new Schedule();
  });
  activitySchedules['Swim'] = new Schedule();

  let activityEnrollment = initializeActivityEnrollment(); //empty structure for holding activity enrollment for each period
  let activityCapacityMap = new Map([...activities, ...otherValidActivities].map(activity => [activity.name, activity.capacity])); // maps activity name to activity capacity
  let activityFrequencyMap = new Map([...activities, ...otherValidActivities].map(activity => [activity.name, activity.max_frequency])); //maps activity name to permitted frequency

  let cabinActivityFrequencies = [];
  let cabinDailyActivities = [];


  
  cabins.forEach(cabin => {               //iterate through every cabin in the array and execute the following function
    const cabinRequests = requests.find(r => r.cabinName === cabin.cabin)?.requests || {}; //find the cabins requests, if there are none, return an empty object
    const schedule = new Schedule();      //create a new schedule for each cabin

    let flags = { //create flags to help with logic of assigning requested periods from each catagory
      specialty: false,
      sports: false,
      groupChoice: false,
      missedPeriods: false
    };
    
    const activityFrequency = initializeActivityFrequency(); //create structure to track activity frequency
    let dailyActivities = initializeDailyActivities(); //create structure to track daily activities

    let unitSwimPeriod = units.find(u => u.unitName === cabin.unit).swimPeriod; //find units where the cabin unit is equal to the unit name and store the correct swim period

    
    
    for (let day = 0; day < schedule.days.length; day++) {      
      for (let period = 0; period < schedule.days[day].periods.length; period++) {     //iterate through all the periods in each day of the schedule
        let selected_activity = null; //initialize chosen activity to null
        
        if (period === unitSwimPeriod) {
          schedule.days[day].addActivity(period, 'Swim');
          activityEnrollment['Swim'][`Day${day}`][`Period${period}`]++;          //if cabin unit has swim at this period, set it and update trackers
          activityFrequency['Swim']++;
          activitySchedules['Swim'].days[day].periods[period].push(cabin.cabin);
          dailyActivities[`Day${day}`].push('Swim');
          continue;
        }
          else if (!flags.specialty) { //if the period is not swim, try to accomadate a specialty request if not done so already
            selected_activity = specialtyRequests(cabin.cabin, requests, activityFrequency, activityFrequencyMap); //get top available choice
            flags.specialty = !!selected_activity; //set the flag to true if we have an activity or false if it was null
          }
          else if (!flags.sports) {
            selected_activity = sportsRequests(cabin.cabin, requests, activityFrequency, activityFrequencyMap); //next request to fullfill
            flags.sports = !!selected_activity;
          }
          else if (!flags.groupChoice) {
            selected_activity = groupChoiceRequests(cabin.cabin, requests, activityFrequency, activityFrequencyMap); //next request to fulfill
            flags.groupChoice = !!selected_activity;
          }
          else if (!flags.missedPeriods) {
            selected_activity = missingPeriodRequests(cabin.cabin, requests, activityFrequency, activityFrequencyMap); //next request to fulfill
            flags.missedPeriods = !!selected_activity;
          }
        
        if (selected_activity != null) {
            if (!isValidActivity(selected_activity, day, period, activityEnrollment, activityFrequency, activityFrequencyMap, activityCapacityMap, dailyActivities)) {
                selected_activity = null; // Reset if constraints not met
            }
        }
        
          



          
        
        if (!selected_activity) { //if activity is not swim, and no request was fullfilled
          selected_activity = getRandomActivity();  //otherwise, randomly generate an activity

          const max_attempts = 15;
          let attempts = 0


          while (activityEnrollment[selected_activity][`Day${day}`][`Period${period}`] >= activityCapacityMap.get(selected_activity) || 
                 activityFrequency[selected_activity] >= activityFrequencyMap.get(selected_activity) ||
                 dailyActivities[`Day${day}`].includes(selected_activity))  {

            if (attempts >= max_attempts) {  //only try 15 times, otherwise, we'll deal with it later
              selected_activity = null;
              break;
            }
            selected_activity = getRandomActivity();  //check if the current enrollment for the selected activity for the selected time is full, if it is, reassign
            attempts++;                                          //check that activity has not exceeded max frequency in schedule, if so, reassign
          }
          

          schedule.days[day].addActivity(period, selected_activity); //add activity to schedule
          if (selected_activity != null){activityEnrollment[selected_activity][`Day${day}`][`Period${period}`]++;} //update the enrollment storing structure

          if (selected_activity != null){activityFrequency[selected_activity]++;} //update the frequency structure

          if (selected_activity != null){activitySchedules[selected_activity].days[day].periods[period].push(cabin.cabin);} //whenever we add an activity to a cabin, add that cabin to the activity
          if (selected_activity != null){dailyActivities[`Day${day}`].push(selected_activity);}
        }
        else { //otherwise, add our requested activity
          schedule.days[day].addActivity(period, selected_activity); //add activity to schedule
          if (selected_activity != null){activityEnrollment[selected_activity][`Day${day}`][`Period${period}`]++;} //update the enrollment storing structure

          if (selected_activity != null){activityFrequency[selected_activity]++;} //update the frequency structure

          if (selected_activity != null){activitySchedules[selected_activity].days[day].periods[period].push(cabin.cabin);} //whenever we add an activity to a cabin, add that cabin to the activity
          if (selected_activity != null){dailyActivities[`Day${day}`].push(selected_activity);}
        }
      }
    }
    cabinSchedules.push({
      cabin : cabin.cabin,
      schedule: schedule.getSchedule() // return the list of all the cabins and their schedules
    });
    cabinActivityFrequencies.push({
      cabin : cabin.cabin,
      activityFrequency : activityFrequency
    });
    cabinDailyActivities.push({
      cabin : cabin.cabin,
      dailyActivities : dailyActivities
    });
    
  });
  

  // Here, we deal with the periods that have not been assigned yet
  let unassigned_periods = {}

  // Iterate through each cabin's schedule in cabinSchedules.
  cabinSchedules.forEach(schedule => {

      // Iterate through each day in a cabin's schedule.
      schedule.schedule.forEach((day, dayIndex) => {

          Object.values(day).forEach((activities, periodIndex) => {

            activities.forEach((activity) => {
              if (activity === null) {
                  if (!unassigned_periods[schedule.cabin]) {                       //if the cabin has a null activity, add it to unassigned periods along with the time slot
                      unassigned_periods[schedule.cabin] = [];
                  }
                  unassigned_periods[schedule.cabin].push({ day: dayIndex, period: periodIndex, available_periods: [] });
              }
            });
          });
      });
  });
  
  Object.keys(unassigned_periods).forEach(cabinName => {   //iterate through all unassigned periods for each cabin
    const cabinFrequency = cabinActivityFrequencies.find(c => c.cabin === cabinName).activityFrequency; // retrieve the activity frequency structure
    unassigned_periods[cabinName].forEach(item => {        //item is a single unassigned period, contains day, period, and array to store available periods
      
      activities.forEach(activity => {                      //iterate through all activities
        
        if (activityEnrollment[activity.name][`Day${item.day}`][`Period${item.period}`] < activityCapacityMap.get(activity.name) &&
            cabinFrequency[activity.name] < activityFrequencyMap.get(activity.name)) {   //if the activity is not at capacity and is not at max frequency already, it is an option
            item.available_periods.push(activity.name);
        }
      });
    });
  });
  
  Object.keys(unassigned_periods).forEach(cabinName => {
    const cabinFrequency = cabinActivityFrequencies.find(c => c.cabin === cabinName).activityFrequency; // retrieve the activity frequency structure
    unassigned_periods[cabinName].forEach(item => {      //iterate through unassigned periods
      if (item.available_periods.length > 0) {
        let randomIndex2 = Math.floor(Math.random() * item.available_periods.length); //if available periods exist, randomly select one
        let selected_activity = item.available_periods[randomIndex2];

        let attempts = 0;
        const max_attempts = 15;
        while (activityEnrollment[selected_activity][`Day${item.day}`][`Period${item.period}`] >= activityCapacityMap.get(selected_activity) || 
              cabinFrequency[selected_activity] >= activityFrequencyMap.get(selected_activity) ||
               cabinDailyActivities.find(da => da.cabin === cabinName).dailyActivities[`Day${item.day}`].includes(selected_activity)) {
          if (attempts >= max_attempts) { //make sure the selected activity satisfies constraints
            selected_activity = null;
            break;
          }
          randomIndex2 = Math.floor(Math.random() * item.available_periods.length); // Re-select from available periods
          selected_activity = item.available_periods[randomIndex2];
          attempts++;
        }

        if (selected_activity != null) {                                                                 //if we find an activity, do the following
          cabinSchedules.find(cs => cs.cabin === cabinName).schedule[item.day][item.period] = selected_activity;                //set that missing period to the one selected
          activitySchedules[selected_activity].days[item.day].periods[item.period].push(cabinName); 
          activityEnrollment[selected_activity][`Day${item.day}`][`Period${item.period}`]++;  //update all trackers
          cabinFrequency[selected_activity]++;
            cabinDailyActivities.find(da => da.cabin === cabinName).dailyActivities[`Day${item.day}`].push(selected_activity);
          
        }
        else {
          cabinSchedules.find(cs => cs.cabin === cabinName).schedule[item.day][item.period] = 'Free Period';   //if we get to this point, just give the cabin a free period
        }
      }
      else {
        cabinSchedules.find(cs => cs.cabin === cabinName).schedule[item.day][item.period] = 'Free Period'; //if no available activities exist, just give the cabin a free period
      }
      
    });
  });
  
  return { cabinSchedules, activitySchedules };
  
}
//------------------------------------------------------------------------------------------------------------------------------------------
function streamToString(stream) { //helper function to formatt s3 response for json return
  return new Promise((resolve, reject) => {
    const read_data = []; //structure for holding the read data
    stream.on('data', (chunk) => read_data.push(chunk)); //as data is read, stick it in our structure
    stream.on('error', reject); //reject if there is an error while processing the data
    stream.on('end', () => resolve(Buffer.concat(read_data).toString('utf8'))); //change read data to string so it can be put in the json
  });
}

module.exports = {         
  getRandomActivity,
  assignRandomSchedules,
  streamToString
};
