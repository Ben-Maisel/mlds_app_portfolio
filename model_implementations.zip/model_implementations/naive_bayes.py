# DONE

import numpy as np
import warnings

from src.utils import softmax
from src.sparse_practice import flip_bits_sparse_matrix


class NaiveBayes:
    """
    A Naive Bayes classifier for binary data.
    """

    def __init__(self, smoothing=1):
        """
        Args:
            smoothing: controls the smoothing behavior when calculating beta
        """
        self.smoothing = smoothing

    def predict(self, X):
        """
        Return the most probable label for each row x of X.
        You should not need to edit this function.
        """
        probs = self.predict_proba(X)
        return np.argmax(probs, axis=1)

    def predict_proba(self, X):
        """
        Using self.alpha and self.beta, compute the probability p(y | X[i, :])
            for each row X[i, :] of X.  The returned array should be
            probabilities, not log probabilities. If you use log probabilities
            in any calculations, you can use src.utils.softmax to convert those
            into probabilities that sum to 1 for each row.

        Don't worry about divide-by-zero RuntimeWarnings.

        Args:
            X: a sparse matrix of shape `[n_documents, vocab_size]` on which to
               predict p(y | x)

        Returns 
            probs: an array of shape `[n_documents, n_labels]` where probs[i, j] contains
                the probability `p(y=j | X[i, :])`. Thus, for a given row of this array,
                np.sum(probs[i, :]) == 1.
        """
        n_docs, vocab_size = X.shape
        n_labels = 2

        assert hasattr(self, "alpha") and hasattr(self, "beta"), "Model not fit!"
        assert vocab_size == self.vocab_size, "Vocab size mismatch"

        log_likelihood = np.zeros((n_docs, n_labels)) # initialize array to store the likelihoods
        not_beta = np.log(1-self.beta) # for the case where the words are not present

        for doc in range(n_docs): # for each document
            
            doc_current = X[doc] # get the document
            
            for label in range(n_labels): # for each label

                logAlpha = np.log(self.alpha[label]) # get the alpha for the current label
                logBeta_present = doc_current.multiply(np.log(self.beta[:,label])).sum() # get the log probs for the words present in the doc
                logBeta_absent = not_beta[:,label].sum() - doc_current.multiply(not_beta[:,label]).sum() # get the log probs for the words absent in the doc

                current_likelihood = logAlpha + logBeta_present + logBeta_absent # sum for the likelihood for current lavel and current doc

                log_likelihood[doc, label] = current_likelihood # update likelihood array

        return softmax(log_likelihood) # soft max to convert from log to standard probs

            

    def fit(self, X, y):
        """
        Compute self.alpha and self.beta using the training data.
        This function *should not* use unlabeled data. Wherever y is NaN, that
        label and the corresponding row of X should be ignored.

        self.alpha should be set to contain the marginal probability of each class label.

        self.beta is an array of shape [n_vocab, n_labels]. self.beta[j, k]
            is the probability of seeing the word j in a document with label k.
            Remember to use self.smoothing. If there are M documents with label
            k, and the `j`th word shows up in L of them, then `self.beta[j, k]`
            is `(L + smoothing) / (M + 2 * smoothing)`.

        Note: all tests will provide X to you as a *sparse array* which will
            make calculations with large datasets much more efficient.  We
            encourage you to use sparse arrays whenever possible, but it can be
            easier to debug with dense arrays (e.g., it is easier to print out
            the contents of an array by first converting it to a dense array).

        Args: X, a sparse matrix of word counts; Y, an array of labels
        Returns: None; sets self.alpha and self.beta
        """

        # filter = ~np.isnan(y)  # true for non nan, false for nan
        # X = X[filter]  # filter out nan
        # y = y[filter]  # filter out nan

        n_docs, vocab_size = X.shape
        n_labels = 2  
        self.vocab_size = vocab_size

        self.alpha = np.zeros(n_labels) # intializae array to store alpha values
        self.beta = np.zeros((self.vocab_size, n_labels)) # initialize array to store beta values

        for label in np.unique(y[~np.isnan(y)]): # for each label that is not null
            labelInt = int(label) # convert to int
            self.alpha[labelInt] = np.sum(y == label) / n_docs # set the alpha for each label to the proportion of docs with that label

        for word in range(self.vocab_size): # for each word in the vocab
            word_col = X[:, word] # get the column vector for that word from all docs

            for label in np.unique(y[~np.isnan(y)]): # for each label that is not null
                label_indexs = np.where(y==label)[0] # get the indexs where that label exists
                docs_word_present = word_col[label_indexs] # just get the rows where the word is present

                self.beta[word, int(label)] = (np.sum(docs_word_present) + self.smoothing) / (len(label_indexs) + (2 * self.smoothing)) # smoothed prob of word appearing in doc of certain class






    def likelihood(self, X, y):
        r"""
        Using the self.alpha and self.beta that were already computed in
            `self.fit`, compute the LOG likelihood of the data.  You should use
            logs to avoid underflow.  This function should not use unlabeled
            data. Wherever y is NaN, that label and the corresponding row of X
            should be ignored.

        Don't worry about divide-by-zero RuntimeWarnings.

        Args: X, a sparse matrix of binary word counts; Y, an array of labels
        Returns: the log likelihood of the data
        """

        # filter = ~np.isnan(y)  # true for non nan, false for nan
        # X = X[filter]  # filter out nan
        # y = y[filter]  # filter out nan

        assert hasattr(self, "alpha") and hasattr(self, "beta"), "Model not fit!"

        n_docs, vocab_size = X.shape
        n_labels = 2

        log_likelihood = 0  # initialize var to store log likelihood

        denseX = X.todense() # convert to dense matrix just to make things easier

        for doc in range(n_docs): # for each doc
            if np.isnan(y[doc]): # if there are nan values for the current doc in the label, ignore it
                continue
            current_label = int(y[doc]) # get the current label and make sure its an int

            label_probs = np.log(self.alpha[current_label]) # get the intial log probs just considering the label

            word_probs_present = np.dot(denseX[doc], np.log(self.beta[:, current_label])) # consider the present words
            word_probs_absent = np.dot(1 - denseX[doc], np.log(1 - self.beta[:, current_label])) # consider the absent words
            word_probs_total = word_probs_present + word_probs_absent

            log_likelihood += (label_probs + word_probs_total) # update the log probs to consider both the label and words for the document

        return log_likelihood






