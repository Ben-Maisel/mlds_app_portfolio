import numpy as np

class BinaryCrossEntropyLoss:
    def forward(self, y_pred, y_true):
        """
        Save the inputs to self.input_ and then compute the binary cross-entropy loss.

        Args:
            y_pred: Predicted values (probabilities).
            y_true: True binary labels.

        Returns:
            Binary cross-entropy loss.
        """
        assert set(np.unique(y_true)).issubset(set([0, 1]))
        y_pred = np.clip(y_pred, 1e-8, 1 - 1e-8)  # no division by zero by setting bounds on array

        if len(y_pred.shape) == 1:
            y_pred = y_pred.reshape(-1, 1)
        if len(y_true.shape) == 1:
            y_true = y_true.reshape(-1, 1)

        self.input_ = (y_pred, y_true)  # save the inputs
        loss = -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred)) # use the formula
        return loss

    def backward(self, grad=None, lr=None):
        """
        Compute the gradient of the binary cross-entropy loss function.
        
        Args:
            grad: Gradient (not used).
            lr: Learning rate (not used).
        
        Returns:
            Gradient of the loss.
        """
        assert grad is None
        y_pred, y_true = self.input_
        grad = (y_pred - y_true) / (y_pred * (1 - y_pred) + 1e-8) # formula and avoid /0
        return grad



class SquaredLoss:
    def forward(self, y_pred, y_true):
        """
        Save the inputs to self.input_ and then compute the mean squared error loss.

        Args:
            y_pred: Predicted values.
            y_true: True values.

        Returns:
            Mean squared error loss.
        """
        if len(y_pred.shape) == 1:
            y_pred = y_pred.reshape(-1, 1)
        if len(y_true.shape) == 1:
            y_true = y_true.reshape(-1, 1)

        self.input_ = (y_pred, y_true)  # save the inputs
        loss = np.mean((y_pred - y_true) ** 2)  # mean squared error
        return loss

    def backward(self, grad=None, lr=None):
        """
        Compute the gradient of the mean squared error loss function.

        Args:
            grad: Gradient (not used).
            lr: Learning rate (not used).

        Returns:
            Gradient of the loss.
        """
        assert grad is None

        y_pred, y_true = self.input_  # use the saved inputs
        grad = 2 * (y_pred - y_true)  # compute gradient
        return grad



# DONE