
def ask(var, value, evidence, bn):


	# the very first thing we must do is update the evidence dict so that var maps to value. this ensures that calculation
	# reflects the scenario where the hypothesis is assumed to be true or false as specified

	updated_evidence = evidence.copy()
	updated_evidence[var] = value

	
	
# helper to calculate joint probabilities
	def joint_probability(evidence, remaining_variables):
		
		#  since there are no remaining variables to consider, the probility of the event is just 1 * the independent probability
		if not remaining_variables:
			return 1
		
		# consider the variables one at a time, remove it from the list and use it for this iteration
		current_variable = remaining_variables[0]
		remaining_variables = remaining_variables[1:]

		# Easy case: if the current variable's probability is known, we can just fetch is probility and use it
		# in our multiplication equation
		if current_variable in evidence:
			node = bn.get_var(current_variable)
			probability = node.probability(evidence[current_variable], evidence)

			# now that we've gotten the probability, we can recursively continue on to the next var in remaining vars
			return probability * joint_probability(evidence, remaining_variables)
		
		# Harder case: if the current variables probalility is not known, then we need to consider the true and false cases
		
		# When a variable value is not known, you cannot directly use a single probability value 
			# for it because its actual state (True or False) affects the overall calculation. 
			# Instead, you need to consider both possibilities:

			# True State: probability of the event if this variable is true?
		
			# False State: What is the probability of the event if this variable is false
		
		# make copies of the evidence dict so we can modify it and set values to true and false without messing everything up
		t_evidence = evidence.copy()
		f_evidence = evidence.copy()

		# update the values of current_varable accordingly
		t_evidence[current_variable] = True
		f_evidence[current_variable] = False

		# now use both of these dicts to recursively explore the joint probability of both paths
		true_probability = joint_probability(t_evidence, remaining_variables)
		false_probability = joint_probability(f_evidence, remaining_variables)
		
		# Sum the resulting probabilities, but MAKE SURE TO WEIGHT BY PROB OF BEING TRUE/FALSE
		node = bn.get_var(current_variable)
		return (true_probability * node.probability(True, evidence)) + (false_probability * node.probability(False, evidence))
	
			
	# to calculate joint probability involving hypothesis and evidence need to consider all variables 
	# in network. create a list for convinient access

	all_var_names = [node.name for node in bn.variables]

	# calculate the probability of hypothesis given evidence using the helper and considering all variables
	hypothesis_given_evidence = joint_probability(updated_evidence, all_var_names)
	
	# flip the value to calculate the case of not hypothesis
	updated_evidence[var] = not value

	# calculate the probability of not hypothesis given evidence using the helper and considering all variables
	not_hypothesis_given_evidence = joint_probability(updated_evidence, all_var_names)

	# determine the normalization constant alpha
	alpha = hypothesis_given_evidence + not_hypothesis_given_evidence

	# finally, return the conditional probability P(H|E)

	return hypothesis_given_evidence / alpha

