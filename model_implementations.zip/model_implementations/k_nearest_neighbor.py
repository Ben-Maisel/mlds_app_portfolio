import numpy as np
from src.distances import euclidean_distances, manhattan_distances, cosine_distances


def find_mode(arr):
    """
    Return the mode (most common element) of `arr`.
    You may use your `numpy_practice` implementation from HW1.
    """
    arr = arr.reshape(-1).astype(int)  # ensure x is a flattened int array
    unique_values, counts = np.unique(arr, return_counts=True) # get unique values and counts of them
    return unique_values[np.argmax(counts)] # get max index and return associated value



class KNearestNeighbor():
    def __init__(self, n_neighbors, distance_measure='euclidean', aggregator="mode"):
        """
        K-Nearest Neighbor is a straightforward algorithm that can be highly
        effective. 

        You should not have to change this __init__ function, but it's
        important to understand how it works.

        Do not import or use these packages: fairlearn, scipy, sklearn, sys, importlib.

        Arguments:
            n_neighbors {int} -- Number of neighbors to use for prediction.
            distance_measure {str} -- Which distance measure to use. Can be
                'euclidean,' 'manhattan,' or 'cosine'. This is the distance measure
                that will be used to compare features to produce labels.
            aggregator {str} -- How to aggregate neighbors; either mean or mode.
        """
        self.n_neighbors = n_neighbors

        if aggregator == "mean":
            self.aggregator = np.mean
        elif aggregator == "mode":
            self.aggregator = find_mode
        else:
            raise ValueError(f"Unknown aggregator {aggregator}")

        if distance_measure == "euclidean":
            self.distance = euclidean_distances
        elif distance_measure == "manhattan":
            self.distance = manhattan_distances
        elif distance_measure == "cosine":
            self.distance = cosine_distances
        else:
            raise ValueError(f"Unknown distance {distance_measure}")

    def fit(self, features, targets):
        """
        Fit features, a numpy array of size (n_samples, n_features). For a KNN, this
        function should store the features and corresponding targets in class
        variables that can be accessed in the `predict` function.

        Arguments:
            features {np.ndarray} -- Features of each data point, shape of (n_samples, n_features).
            targets -- Target labels for each data point, shape of (n_samples, 1).
        """
        features = np.asarray(features) # get features as np array
        targets = np.asarray(targets) # get targets as np array

        # first, check to make sure the arrays have the right dims and shapes or else everything wont work
        if features.ndim != 2:
            raise ValueError("features array has wrong dims")
        if targets.ndim != 1 and targets.ndim != 2:
            raise ValueError("targets array has wrong dims")
        if targets.ndim == 2 and targets.shape[1] != 1:
            raise ValueError("targets array has wrong shape for dims")
        
        # the number of samples in features has to be the same as number of targets
        if features.shape[0] != targets.shape[0]:
            raise ValueError("number of samples in features and targets are not equal")
        
        # if all is good, set vars
        self.features = features
        self.targets = targets




    def predict(self, features):
        """
        Use the training data to predict labels on the test features.

        For each test example, find the `self.n_neighbors` closest train
        examples, in terms of the `self.distance` measure. Then, predict the
        test label by using `self.aggregator` among those nearest neighbors.

        Arguments:
            features {np.ndarray} -- Features of each data point, shape of
                (n_samples, n_features).

        Returns:
            labels {np.ndarray} -- Labels for each data point, of shape
                (n_samples, 1).
        """
        features = np.asarray(features) # get features as np array
        distances = self.distance(features, self.features) # get distance between testing and training samples
        neighbors_indexs = np.argsort(distances, axis=1)[:, :self.n_neighbors] # sort the array od distances, get the n number of indexs of nearest distances
        neighbors_labels = self.targets[neighbors_indexs] # index the targets array with the nearest neighbors indexs to get the labels
        test_labels = np.apply_along_axis(self.aggregator, 1, neighbors_labels) # apply the aggreagtor across the row (axis 1) of neighbors_labels (the training labels)
        
        return test_labels.reshape(-1, 1) # reshape to be a column vector of the calculated labels. (-1,1) means as many rows as needed (n_samples) 1, means one a single column

