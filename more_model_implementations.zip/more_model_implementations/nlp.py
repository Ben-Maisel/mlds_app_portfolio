import read, copy
from util import *
from logical_classes import *

verbose = 0

class KnowledgeBase(object):
    def __init__(self, facts=[], rules=[]):
        self.facts = facts
        self.rules = rules
        self.ie = InferenceEngine()

    def __repr__(self):
        return 'KnowledgeBase({!r}, {!r})'.format(self.facts, self.rules)

    def __str__(self):
        string = "Knowledge Base: \n"
        string += "\n".join((str(fact) for fact in self.facts)) + "\n"
        string += "\n".join((str(rule) for rule in self.rules))
        return string

    def _get_fact(self, fact):
        """INTERNAL USE ONLY
        Get the fact in the KB that is the same as the fact argument

        Args:
            fact (Fact): Fact we're searching for

        Returns:
            Fact: matching fact
        """
        for kbfact in self.facts:
            if fact == kbfact:
                return kbfact

    def _get_rule(self, rule):
        """INTERNAL USE ONLY
        Get the rule in the KB that is the same as the rule argument

        Args:
            rule (Rule): Rule we're searching for

        Returns:
            Rule: matching rule
        """
        for kbrule in self.rules:
            if rule == kbrule:
                return kbrule

    def kb_add(self, fact_rule):
        """Add a fact or rule to the KB
        Args:
            fact_rule (Fact or Rule) - Fact or Rule to be added
        Returns:
            None
        """
        printv("Adding {!r}", 1, verbose, [fact_rule])
        if isinstance(fact_rule, Fact):
            if fact_rule not in self.facts:
                self.facts.append(fact_rule)
                for rule in self.rules:
                    self.ie.fc_infer(fact_rule, rule, self)
            else:
                if fact_rule.supported_by:
                    ind = self.facts.index(fact_rule)
                    for f in fact_rule.supported_by:
                        self.facts[ind].supported_by.append(f)
                else:
                    ind = self.facts.index(fact_rule)
                    self.facts[ind].asserted = True
        elif isinstance(fact_rule, Rule):
            if fact_rule not in self.rules:
                self.rules.append(fact_rule)
                for fact in self.facts:
                    self.ie.fc_infer(fact, fact_rule, self)
            else:
                if fact_rule.supported_by:
                    ind = self.rules.index(fact_rule)
                    for f in fact_rule.supported_by:
                        self.rules[ind].supported_by.append(f)
                else:
                    ind = self.rules.index(fact_rule)
                    self.rules[ind].asserted = True

    def kb_assert(self, fact_rule):
        """Assert a fact or rule into the KB

        Args:
            fact_rule (Fact or Rule): Fact or Rule we're asserting
        """
        printv("Asserting {!r}", 0, verbose, [fact_rule])
        self.kb_add(fact_rule)

    def kb_ask(self, fact):
        """Ask if a fact is in the KB

        Args:
            fact (Fact) - Statement to be asked (will be converted into a Fact)

        Returns:
            listof Bindings|False - list of Bindings if result found, False otherwise
        """
        print("Asking {!r}".format(fact))
        if factq(fact):
            f = Fact(fact.statement)
            bindings_lst = ListOfBindings()
            # ask matched facts
            for fact in self.facts:
                binding = match(f.statement, fact.statement)
                if binding:
                    bindings_lst.add_bindings(binding, [fact])

            return bindings_lst if bindings_lst.list_of_bindings else []

        else:
            print("Invalid ask:", fact.statement)
            return []

    def kb_retract(self, fact_rule):
        """Retract a fact or a rule from the KB

        Args:
            fact_rule (Fact or Rule) - Fact or Rule to be retracted

        Returns:
            None
        """
        printv("Retracting {!r}", 0, verbose, [fact_rule])
        ####################################################
        # Student code goes here
        
        # case 1, the fact_rule is a fact
        if isinstance(fact_rule, Fact): # check if its a fact
            fact = self._get_fact(fact_rule) # get the actual fact
            if fact.supported_by: # first, the case where it is supported
                if fact.asserted: # if its asserted, unassert it and return
                    fact.asserted = False
                    return
            


            # the next case is that the fact is not supported
            else:
                if fact in self.facts: # if the fact is in the kb, remove it
                    self.facts.remove(fact)

                    
                    
                    for x in (fact.supports_facts + fact.supports_rules):
                        for pair in x.supported_by:
                            if fact in pair:
                                x.supported_by.remove(pair)
                        if not x.supported_by and not x.asserted:
                            self.kb_retract(x)
                        




        # case 2, fact_rule is a rule
        elif isinstance(fact_rule, Rule):
            rule = self._get_rule(fact_rule)
            if rule.supported_by:
                if rule.asserted:
                    rule.asserted = False
                    return
            




            else:
                if rule in self.rules: # remove the rule if its not supported and in the kb
                    self.rules.remove(rule)
                    
                    
                    for y in (rule.supports_facts + rule.supports_rules):
                        for pair in y.supported_by:
                            if rule in pair:
                                y.supported_by.remove(pair)
                        if not y.supported_by and not y.asserted:
                            self.kb_retract(y)














        # #if the fact/rule is not supported, return early
        # if not fact_rule.supported_by:
        #     return
        
        # # if fact rule is a rule that exist in the kb and is not supported, remove it
        # if isinstance(fact_rule, Rule) and fact_rule in self.rules and not fact_rule.supported_by:
        #     self.rules.remove(fact_rule)

        # # if fact rule is a fact
        #     f = False
        #     for fact in self.facts: # iterate through the facts, check if the fact statement in the kb
        #         if fact_rule.statement == fact.statement:
        #             fact_rule = fact # if the statements are the same, the fact is in the kb
        #             f = True # update the flag and break from the loop
        #             break
        #         # if the fact is not in the kb, return early
        #     if not f:
        #         return
        #     # if the fact has no support, remove it
        #     if not fact_rule.supported_by:
        #         self.facts.remove(fact_rule)

        # # iterate through all supported facts and update support stuff
        # for supported_fact in fact_rule.supports_facts:
        #     for pair in supported_fact.supported_by:
        #         # supported by is a pair so check if the fact_rule is in the pair
        #         if fact_rule in pair:
        #             supported_fact.supported_by.remove(pair)
        #     if not supported_fact.supported_by: # if it has no support retract it recursively
        #         self.kb_retract(supported_fact)

        # # iterate through all supported rules and update support stuff
        # for supported_rule in fact_rule.supports_rules:
        #     for pair in supported_rule.supported_by:
        #         if fact_rule in pair:
        #             supported_rule.supported_by.remove(pair)
        #     if not supported_rule.supported_by:
        #         self.kb_retract(supported_rule)
            
                











        # if isinstance(fact_rule, Fact) and fact_rule in self.facts: #get the fact from the factrule if it is a fact
        #     fact = self._get_fact(fact_rule)
        # elif isinstance(fact_rule, Rule) and fact_rule in self.rules and not fact_rule.asserted: # same if its a rule, we only was rules that are not asserted
        #     fact = self._get_rule(fact_rule)
        # else:
        #     return  # If not in kb or is an asserted rule, do nothing
        
        # if fact.asserted or len(fact.supported_by) > 0:
        #     if fact.asserted:
        #         fact.asserted = False  # unassert if it was asserted
        #     return  # do not remove if it has support
        
        # if isinstance(fact, Fact): #if not asserted and no support, remove it from kb
        #     self.facts.remove(fact)
        # else:
        #     self.rules.remove(fact)

        

        # # iterate over all facts and rules that were directly supported by the fact/rule being retracted
        # for supported_by in fact.supports_facts + fact.supports_rules:
        #     # iterate over each pair of supports (fact-rule pairs) for the currently examined supported fact/rule
        #     for support in supported_by.supported_by:
        #         # check if the fact/rule being retracted is part of the support for the supported fact/rule
        #         if fact in support:
        #             # if so, remove it from support
        #             supported_by.supported_by.remove(support)
        #             # if not supported and no support, remove
        #             if not supported_by.asserted and len(supported_by.supported_by) == 0:
        #                 self.kb_retract(supported_by)



class InferenceEngine(object):
    def fc_infer(self, fact, rule, kb):
        """Forward-chaining to infer new facts and rules

        Args:
            fact (Fact) - A fact from the KnowledgeBase
            rule (Rule) - A rule from the KnowledgeBase
            kb (KnowledgeBase) - A KnowledgeBase

        Returns:
            Nothing
        """
        printv('Attempting to infer from {!r} and {!r} => {!r}', 1, verbose,
            [fact.statement, rule.lhs, rule.rhs])
        ####################################################
        # Student code goes here


        # the first thing that needs to be done is ensure that the fact matches the rules left hand side. if it doesnt or the rule doesnt have a lhs, return

        # if we have a match, try to create the binding
    
        new_binding = match(rule.lhs[0], fact.statement)
        if not new_binding:
            return

        # if the binding was successfully created, we can now use the binding to make new facts and rules. There are two cases, the first case is that the
            # rule lhs only has one conditon in which case we can make a new fact easily because the only condition is met
        if new_binding != False: # (match helper worked)
            if len(rule.lhs) == 1:
                new_statement = instantiate(rule.rhs, new_binding) # this helper creates a statement from an old one that binds values to the statement variables
                #create a new fact using the new fact statement
                new_fact = Fact(new_statement, supported_by=[[fact, rule]]) # since we created the fact from the binding of the fact and rule.lhs, the fact and rule support it
                # put the new fact into the knowledge base
                fact.supports_facts.append(new_fact)
                rule.supports_facts.append(new_fact)
                kb.kb_add(new_fact)
            
            # if the binding is valid, but the rule has multiple conditions on lhs, then we cannot directly infer rhs because not all conditions are met
                # instead, we create a simplified rule where the first condition (that we know matches) is removed
                # this simpler rule then waits for the remaining conditions to be satisfied either by facts that already exist or facts that will be added
                # a fact can only be created when all conditions of a rule are satisfied
                # a new rule is created when only part of a rules conditions are satisfied

            else: #there are multiple conditions
                new_lhs = [instantiate(x, new_binding) for x in rule.lhs[1:]] # try to instatiate the binding with the remaining condition in the rule. Skip the first because we already did that
                new_rhs = instantiate(rule.rhs, new_binding)
                # print(new_lhs,'-----------------------' ,new_rhs)
                new_rule = Rule([new_lhs, new_rhs], supported_by=[[fact, rule]])
                fact.supports_rules.append(new_rule)
                rule.supports_rules.append(new_rule)
                kb.kb_add(new_rule)
                

                