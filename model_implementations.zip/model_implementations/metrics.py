import numpy as np
# Note: do not import additional libraries to implement these functions


def compute_confusion_matrix(actual, predictions):
    """
    Given predictions (an N-length numpy vector) and actual labels (an N-length
    numpy vector), compute the confusion matrix. The confusion
    matrix for a binary classifier would be a 2x2 matrix as follows:

    [
        [true_negatives, false_positives],
        [false_negatives, true_positives]
    ]

    You do not need to implement confusion matrices for labels with more
    classes. You can assume this will always be a 2x2 matrix.

    Compute and return the confusion matrix.

    Args:
        actual (np.array): predicted labels of length N
        predictions (np.array): predicted labels of length N

    Output:
        confusion_matrix (np.array): 2x2 confusion matrix between predicted and actual labels

    """

    if predictions.shape[0] != actual.shape[0]:
        raise ValueError("predictions and actual must be the same length!")

    cm = np.zeros((2,2), dtype=int) # initialize the matrix to all 0

    for a,p in zip(actual, predictions): # zip the arrays together and iterate over each set of actual vs predicted labels
        if a == 0 and p == 0:
            cm[0, 0] += 1  # true negative
        elif a == 0 and p == 1:
            cm[0, 1] += 1  # false positive
        elif a == 1 and p == 0:
            cm[1, 0] += 1  # false negative
        elif a == 1 and p == 1:
            cm[1, 1] += 1  # true positive

    return cm



def compute_accuracy(actual, predictions):
    """
    Given predictions (an N-length numpy vector) and actual labels (an N-length
    numpy vector), compute the accuracy:

    Hint: implement and use the compute_confusion_matrix function!

    Args:
        actual (np.array): predicted labels of length N
        predictions (np.array): predicted labels of length N

    Output:
        accuracy (float): accuracy
    """
    if predictions.shape[0] != actual.shape[0]:
        raise ValueError("predictions and actual must be the same length!")

    cm = compute_confusion_matrix(actual, predictions) # get matrix
    tp = cm[1,1]
    tn = cm[0,0]

    accuracy = (tp + tn) / np.sum(cm)
    return accuracy


def compute_precision_and_recall(actual, predictions):
    """
    Given predictions (an N-length numpy vector) and actual labels (an N-length
    numpy vector), compute the precision and recall:

    https://en.wikipedia.org/wiki/Precision_and_recall

    You MUST account for edge cases in which precision or recall are undefined
    by returning np.nan in place of the corresponding value.

    Hint: implement and use the compute_confusion_matrix function!

    Args:
        actual (np.array): predicted labels of length N
        predictions (np.array): predicted labels of length N

    Output a tuple containing:
        precision (float): precision
        recall (float): recall
    """
    if predictions.shape[0] != actual.shape[0]:
        raise ValueError("predictions and actual must be the same length!")

    cm = compute_confusion_matrix(actual, predictions) # get matrix
    tp = cm[1,1]
    fp = cm[0,1]
    fn = cm[1,0]
    tn = cm[0,0]

    try:
        precision = tp / (tp + fp)
    except ZeroDivisionError:
        precision = np.nan

    try:
        recall = tp / (tp + fn)
    except ZeroDivisionError:
        recall = np.nan

    return precision, recall


def compute_f1_measure(actual, predictions):
    """
    Given predictions (an N-length numpy vector) and actual labels (an N-length
    numpy vector), compute the F1-measure:

    https://en.wikipedia.org/wiki/Precision_and_recall#F-measure

    Because the F1-measure is computed from the precision and recall scores, you
    MUST handle undefined (NaN) precision or recall by returning np.nan. You
    should also consider the case in which precision and recall are both zero.

    Hint: implement and use the compute_precision_and_recall function!

    Args:
        actual (np.array): predicted labels of length N
        predictions (np.array): predicted labels of length N

    Output:
        f1_measure (float): F1 measure of dataset (harmonic mean of precision and
        recall)
    """
    if predictions.shape[0] != actual.shape[0]:
        raise ValueError("predictions and actual must be the same length!")

    precision, recall = compute_precision_and_recall(actual, predictions)

    if np.isnan(precision) or np.isnan(recall): # edge case 1, no precision, recall
        return np.nan
    
    if precision == 0 and recall == 0: # edge case 2, precision and recall are both 0
        return np.nan
    
    f1_measure = 2 * (precision * recall) / (precision + recall)
    return f1_measure

