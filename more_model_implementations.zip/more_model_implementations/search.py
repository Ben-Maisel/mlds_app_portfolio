from expand import expand
import heapq



def form_path(parent_map, current_node): #helper function to update the parent map
		
		path = [] # initialize a list that will store the path from the start node to the end node
		
		while current_node is not None: #this function reconstructs the path backwards, so current node is always the parent of the previous current node
														# for this reason, it will be none when it is the 'parent' of the start node, then we break the loop
			path.insert(0, current_node) # we are constructing backwards so each current node is the parent of the previous current node. Insert it into slot 0 of the list
			current_node = parent_map[current_node] # update the current node to be the parent of the current node

		return path


def a_star_search (dis_map, time_map, start, end):
	
	# f(n) = g(n) + h(n) -- estimated total cost to get to node 'n'
		# g(n) = cost of path from start node to node 'n'
		# h(n) = heuristic estimate of cost to get from n to the goal
	
	# STEPS:
		
		#1. start with open list containing only the start node then enter main loop
		#Until goal node is reached or open list is empty:
		#2. Pick node from open list with the lowest f(n)
		#3. Expand the picked node and update the parent map such that the expanded nodes are marked as children of the current node
		#4. For each child, calculate g(n), h(n), f(n). If a child is already in the open list with lower f(n), skip updating it
		#5. once goal node is reached, reconstruct path
	
	# For this assignment, the time map represents the actual cost, g(n), between nodes
	# the distance map represents the heuristic estimate, h(n)


	if start == None:
		print("Error: There is no starting node") # ensure that there is actually a starting node
		return -1
	
	if end == None:
		print("Error: There is no target node") # ensure that there is actually a goal node
		return -1
	
	if start == end: # simplest case -- the target node is the same as the first node
		return [start]

	pq = [] # first, intialize the list that we will use as the priority queue
	heapq.heappush(pq, (dis_map[start][end],start)) # since this is the start node, g(n) = 0. the priority value f(n) is therefore just h(n)

	checked_nodes = set() # keep track of nodes already checked so we don't have duplicates in the priority queue

	g_costs = {start: 0} # a dictionary to keep track of the cost of moving from one node to another, essential for calculating g(n) for each node
	parent_map = {start: None} # a dictionary that will keep track of all of a nodes parents, start node has no parent
	

	def g_dist(g_costs, node): # helper function to get g(n) for the current node
		return g_costs.get(node, float('inf')) # get the g(n) of the node, if not found, return infinity so the priority is not before any found nodes

	def h_dist(dis_map, end, node): # helper function to get h(n) for the current node
		return dis_map[node][end]  # look up the distance from the current node to the goal node in the distance map and return that value
	

	# ENTER MAIN LOOP

	while pq:
		
		current_f, current_node = heapq.heappop(pq) # recall that each item in hpq is a tuple with the priority value f(n) and the node itself. 
													# This will assign f(n) to current_f and the node itself to current_node
		
		if current_node in checked_nodes: # skip the current node if we have already checked it. no point in checking it again
			continue

		checked_nodes.add(current_node) # add the current node the set of checked nodes

		if current_node == end:
			return form_path(parent_map, current_node) # if we've reached the goal node, reconstruct the path to it
		
		for node in expand(current_node, time_map): # if we have not found the goal, expand the current node and update the priority queue

			if time_map[current_node][node] is None: # if there are no similarity points between the node and its neighbor, they are not connected so skip it
				continue

			g_n = g_dist(g_costs, current_node) + time_map[current_node][node] # calculate g(n) by adding the cost to get the current node and the cost from the current node to the expanded node

			# we only set this as g(n) if it is a better path than any previous path we've found. Recall if it is not there yet, the function will return the defualt value inf
			if g_n < g_dist(g_costs, node):
				g_costs[node] = g_n # if it is better (shorter path) than update the cost dictionary
				h_n = h_dist(dis_map, end, node) # calculate the distance from the expanded child node to the goal node
				f_n = g_n + h_n # calculate f(n), this will be used to update the priority queue order

				heapq.heappush(pq, (f_n, node)) # add the expanded child node to the priority queue along with its calculated f(n) which is its priority
				parent_map[node] = current_node # update the parent dictionary so that the child node is linked back to its parent for path construction purposes

			
	print('Goal node was not found')
	return None # if we reach this point, then we have exited the loop. Something went wrong and the goal node was not found

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

def depth_first_search(time_map, start, end):
	
	stack = [] # stack can be implemented using a list. Nodes to be searched will be stored here
	checked_nodes = set() # nodes that have already been searched will be stored here. This will ensure we only check each node once at most

	if start == None:
		print("Error: There is no starting node") # ensure that there is actually a starting node
		return -1
	
	if end == None:
		print("Error: There is no target node") # ensure that there is actually a goal node
		return -1
	
	if start == end: # simplest case -- the target node is the same as the first node
		return [start]
	
	stack.append(start) # begin by adding the starting node to the stack

	parent_map = {start: None} # a dictionary that will keep track of all of a nodes parents, start node has no parent


	while stack:

		current_node = stack.pop() # update the current node each iteration of the loop

		if current_node not in checked_nodes: #if the current node is not yet checked
			checked_nodes.add(current_node) # add currrent node to checked nodes
			
			if current_node == end: # if we find the target node
				return form_path(parent_map, current_node)

			for node in expand(current_node, time_map): # expand the current node to get its children, add them to the stack and remove the node we just checked
				if node not in checked_nodes:
					stack.append(node)
					parent_map[node] = current_node # make sure to add the parent of each node to the dictionary
		

	return None # if we get here, something went wrong and the end node was node found

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

def breadth_first_search(time_map, start, end):
	queue = [] # queue can be implemented using a list. Nodes to be searched will be stored here
	checked_nodes = set() # nodes that have already been searched will be stored here. This will ensure we only check each node once at most

	if start == None:
		print("Error: There is no starting node") # ensure that there is actually a starting node
		return -1
	
	if end == None:
		print("Error: There is no target node") # ensure that there is actually a goal node
		return -1
	
	if start == end: # simplest case -- the target node is the same as the first node
		return [start]
	
	queue.append(start) # begin by adding the starting node to the queue

	parent_map = {start: None} # a dictionary that will keep track of all of a nodes parents, start node has no parent

	while queue:

		current_node = queue.pop(0) # update the current node each iteration of the loop

		if current_node not in checked_nodes: #if the current node is not yet checked
			checked_nodes.add(current_node) # add currrent node to checked nodes
			
			if current_node == end: # if we find the target node
				return form_path(parent_map, current_node)

			for node in expand(current_node, time_map): # expand the current node to get its children, add them to the queue and remove the node we just checked
				if node not in checked_nodes:
					queue.append(node)
					parent_map[node] = current_node # make sure to add the parent of each node to the dictionary
		

	return None # if we get here, something went wrong and the end node was node found