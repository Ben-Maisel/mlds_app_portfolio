library(shiny)
library(bslib)
library(tidyverse)

# Define UI ----
ui <- page_sidebar(
  title = "A Cool State",
  sidebar = sidebar(
    h3("Fun Facts:"),
    p(
      strong("State Nickname:"),
      br(),
      "The Pine Tree State"
    ),
    p(
      strong("State Motto:"),
      br(),
      '"Dirigo" ("I Lead")'
    ),
    p(
      strong("Population:"),
      br(),
      "1,344,212 (2023 est)"
    ),
    p(
      strong("State Fossil:"),
      br(),
      "Pertica quadrifaria"
    ),
    p(
      strong("State Insect:"),
      br(),
      "Honeybee"
    ),
    p(
      strong("State Flag:"),
      br(),
      img(src = "flag.png", height = "100px")
    ),
    p(
      strong("State Seal:"),
      br(),
      img(src = "seal.png", height = "100px")
    )
  ),
  fluidRow(
    column(
      width = 6,
      card(
        card_header("Maine"),
        div(
          style = "text-align: center",
          img(src = "maine.jpg", style = "width: 100%; height: auto")
        ),
        p("Note: Maine is known for its scenic coastline and maritime history."),
        p(
          "For more information visit ",
          a("Maine's Wikipedia Page", href = "https://en.wikipedia.org/wiki/Maine", target = "_blank")
        ),
        card_footer("Maine is a state in the northeastern United States.")
      )
    ),
    column(
      width = 6,
      card(
        card_header("Fun Thing to Do in Maine"),
        div(
          style = "text-align: center",
          img(src = "park.jpg", style = "width: 100%; height: auto")
        ),
        p("Visit Acadia National Park!"),
        p(
          "Learn more about it on ",
          a("Acadia National Park's official page", href = "https://www.nps.gov/acad/index.htm", target = "_blank")
        )
      )
    )
  )
)

# Define server logic ----
server <- function(input, output) {
  
}

# Run the app ----
shinyApp(ui = ui, server = server)