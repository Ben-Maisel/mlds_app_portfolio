# client for schedule app

import requests  # calling web service
# import jsons  # relational-object mapping
import pathlib
import logging
import sys
import os
import class_definitions
import json
from configparser import ConfigParser
import cabinScheduleGraphic
import activityScheduleGraphic




###################################################################
#
# prompt
#
def prompt():
  """
  Prompts the user and returns the command number
  
  Parameters
  ----------
  None
  
  Returns
  -------
  Command number entered by user (0, 1, 2, ...)
  """
  print()
  print(">> Enter a command:")
  print("   0 => end")
  print("   1 => get cabins")
  print("   2 => get activities")
  print("   3 => generate schedules")
  print("   4 => get current cabin schedules")
  print("   5 => get current activity schedules")
  print("   6 => get past cabin schedules")
  print("   7 => get past activity schedules")

  cmd = int(input())
  return cmd


###################################################################
#
# get_cabins
#
def get_cabins(baseurl):


  try:
    #
    # call the web service:
    #
    api = '/get_cabins'
    url = baseurl + api

    res = requests.get(url)
    #
    # let's look at what we got back:
    #
    if res.status_code != 200:
      # failed:
      print("Failed with status code:", res.status_code)
      print("url: " + url)
      if res.status_code == 400:  # we'll have an error message
        body = res.json()
        print("Error message:", body["message"])
      #
      return

    #
    # 
    #
    body = res.json()
  
    cabins = []
    for row in body["data"]:
      cabin = class_definitions.Cabin(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      cabins.append(cabin)

    for cabin in cabins:
      print("cabin id: ",cabin.cabinid)
      print(" ","cabin name: ", cabin.cabin_name)
      print(" ","current schedule key: ", cabin.current_schedule_key, "\n")

  except Exception as e:
    logging.error("get_cabins() failed:")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
#
# get_activities
#
def get_activities(baseurl):
 

  try:
    #
    # call the web service:
    #
    api = '/get_activities'
    url = baseurl + api

    res = requests.get(url)

    #
    # let's look at what we got back:
    #
    if res.status_code != 200:
      # failed:
      print("Failed with status code:", res.status_code)
      print("url: " + url)
      if res.status_code == 400:  # we'll have an error message
        body = res.json()
        print("Error message:", body["message"])
      #
      return

    #
    # 
    #
    body = res.json()
  
    activities = []
    for row in body["data"]:
      activity = class_definitions.Activity(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      activities.append(activity)

    for activity in activities:
      print("activity id: ",activity.activityid)
      print(" ","activity name: ", activity.activity_name)
      print(" ","current schedule key: ", activity.current_schedule_key, "\n")

  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


#########################################################################
###################################################################
#
# generate_schedules
#

def get_activity_choices(prompt, num_choices=5): # helper function to construct json to pass to generate schedules
  choices = {}
  for i in range(1, num_choices + 1):
    choice = input(f"{prompt} Choice {i} (enter 0 for no request): ") # general message printed at each request input
    if choice == '0':
            # Set all remaining choices, including the current one, to none and leave loop
            for j in range(i, num_choices + 1):
                choices[f"Choice{j}"] = None
            break  
    choices[f"Choice{i}"] = choice # otherwise, set choice
  return choices


def make_requests(): # also helper to construct json
    cabin_requests = int(input('Enter how many cabins are making requests (int [0, 32]): '))
  
    if cabin_requests <= 0 or cabin_requests > 32:
        print("Invalid number of cabins")
        return []

    cabin_data = []

    for _ in range(cabin_requests):                                            # get all requests
        cabin_name = input("Enter Cabin Name: ")
        specialty_choices = get_activity_choices("Enter Activity Specialty")
        sports_choices = get_activity_choices("Enter Activity Sport")
        group_choices = get_activity_choices("Enter Group Choice Activity")
        missed_choices = get_activity_choices("Enter Missed Activity")

        cabin_info = {                                                     # format for the json file
            "cabinName": cabin_name,
            "requests": {
                "specialtyPeriodRequests": specialty_choices,
                "sportsRequests": sports_choices,
                "groupChoicePeriod": group_choices,
                "missedActivities": missed_choices
            }
        }

        cabin_data.append(cabin_info)

    with open('cabin_requests.json', 'w') as file:
        json.dump(cabin_data, file, indent=4)  #acually write and save the json file

    return cabin_data
      




def generate_schedules(baseurl):

  try:
    #
    # call the web service:
    #

    json_data = make_requests() # get our requests

    api = '/generate_schedules'
    url = baseurl + api

    res = requests.post(url, json=json_data)

    if res.status_code != 200:
      #failed:
      print("Failed with status code:", res.status_code)
      print("url: " + url)
      print(res.body["message"])
      if res.status_code == 400:
        body = res.json()
        print("Error message:", body)

      return

    body = res.json()
    print(body["message"])

  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
#
# get_cabinCurrent_schedule
#
def get_cabinCurrent_schedule(baseurl):
  
  try:

    num_cabins = input("How Many Cabins Would You Like to Retrieve the Current Schedule For? (int [1, 32]): ")
    if not num_cabins.isdigit():
      print("Invalid number of cabins")
      return []
    num_cabins = int(num_cabins)
    if num_cabins not in range(1,33):
      print("Invalid number of cabins")
      return []
    
    cabins = []

    for _ in range(num_cabins):
      cabinName = input("Enter cabin name:")
      cabins.append(cabinName)
    
    cabins = list(set(cabins)) #remove duplicates just in case

    with open('cabins_requesting_current_schedules.json', 'w') as file:
        json.dump(cabins, file, indent=4)  #acually write and save the json file

    api = '/get_cabinCurrent_schedule'
    url = baseurl + api
    res = requests.post(url, json=cabins)

    if res.status_code != 200:
      if res.status_code == 400:
        print("Failed with status code:", res.status_code)
        print("url: " + url)
        return

      print('failed')
      return

    body = res.json()
    current_schedules = []
    for row in body["data"]:
      schedule = class_definitions.CabinSchedule(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      current_schedules.append(schedule)
      cabinScheduleGraphic.create_schedule_image(schedule.schedule, schedule.cabinName)

    for schedule in current_schedules:
      print("cabin name: ",schedule.cabinName)
      print(" ","cabin id: ", schedule.cabinId)
      print(" ","schedule: ", schedule.schedule, "\n")
      


  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
#
# get_activityCurrent_schedule
#
def get_activityCurrent_schedule(baseurl):
  
  try:

    num_activities = input("How Many Activities Would You Like to Retrieve the Current Schedule For? (int [1, 44]): ")
    if not num_activities.isdigit():
      print("Invalid number of activities")
      return []
    num_activities = int(num_activities)
    if num_activities not in range(1,45):
      print("Invalid number of activities")
      return []
    
    activities = []

    for _ in range(num_activities):
      activityName = input("Enter activity name:")
      activities.append(activityName)
    
    activities = list(set(activities)) #remove duplicates just in case

    with open('activities_requesting_current_schedules.json', 'w') as file:
        json.dump(activities, file, indent=4)  #acually write and save the json file

    api = '/get_activityCurrent_schedule'
    url = baseurl + api
    res = requests.post(url, json=activities)

    if res.status_code != 200:
      if res.status_code == 400:
        print("Failed with status code:", res.status_code)
        print("url: " + url)
        return

      print('failed')
      return

    body = res.json()
    current_schedules = []
    for row in body["data"]:
      schedule = class_definitions.ActivitySchedule(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      current_schedules.append(schedule)
      
      activityScheduleGraphic.create_schedule_image(schedule.schedule, schedule.activityName)

    for schedule in current_schedules:
      print("activity name: ",schedule.activityName)
      print(" ","activity id: ", schedule.activityId)
      print(" ","schedule: ", schedule.schedule, "\n")
      


  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
###################################################################
#
# get_pastCabin_schedule
#
def get_pastCabin_schedule(baseurl):
  
  try:

    num_cabins = input("How Many Cabins Would You Like to Retrieve the Past Schedules For? (int [1, 32]): ")
    if not num_cabins.isdigit():
      print("Invalid number of cabins")
      return []
    num_cabins = int(num_cabins)
    if num_cabins not in range(1,33):
      print("Invalid number of cabins")
      return []
    
    cabins = []

    for _ in range(num_cabins):
      cabinName = input("Enter cabin name:")
      cabins.append(cabinName)
    
    cabins = list(set(cabins)) #remove duplicates just in case

    with open('cabins_requesting_past_schedules.json', 'w') as file:
        json.dump(cabins, file, indent=4)  #acually write and save the json file

    api = '/get_pastCabin_schedule'
    url = baseurl + api
    res = requests.post(url, json=cabins)

    if res.status_code != 200:
      if res.status_code == 400:
        print("Failed with status code:", res.status_code)
        print("url: " + url)
        return

      print('failed')
      return

    body = res.json()
    current_schedules = []
    for row in body["data"]:
      schedule = class_definitions.PastCabinSchedule(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      current_schedules.append(schedule)
      cabinScheduleGraphic.create_pastschedule_image(schedule.schedule, schedule.schedule_date, schedule.cabinName)

    for schedule in current_schedules:
      print("cabin name: ",schedule.cabinName)
      print(" ","cabin id: ", schedule.cabinId)
      print(" ","schedule id: ", schedule.scheduleId)
      print(" ","schedule date: ", schedule.schedule_date)
      print(" ","schedule: ", schedule.schedule, "\n")
      


  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
###################################################################
#
# get_pastActivity_schedule
#
def get_pastActivity_schedule(baseurl):
  
  try:

    num_activities = input("How Many Activities Would You Like to Retrieve the Past Schedules For? (int [1, 44]): ")
    if not num_activities.isdigit():
      print("Invalid number of activities")
      return []
    num_activities = int(num_activities)
    if num_activities not in range(1,45):
      print("Invalid number of activities")
      return []
    
    activities = []

    for _ in range(num_activities):
      activityName = input("Enter activity name:")
      activities.append(activityName)
    
    activities = list(set(activities)) #remove duplicates just in case

    with open('activities_requesting_past_schedules.json', 'w') as file:
        json.dump(activities, file, indent=4)  #acually write and save the json file

    api = '/get_pastActivity_schedule'
    url = baseurl + api
    res = requests.post(url, json=activities)

    if res.status_code != 200:
      if res.status_code == 400:
        print("Failed with status code:", res.status_code)
        print("url: " + url)
        return

      print('failed')
      return

    body = res.json()
    current_schedules = []
    for row in body["data"]:
      schedule = class_definitions.PastActivitySchedule(
        **row
      )  #**row unpacks dictionary into keyword arguments that the constructor can use
      current_schedules.append(schedule)
      
      activityScheduleGraphic.create_pastschedule_image(schedule.schedule, schedule.schedule_date, schedule.activityName)

    for schedule in current_schedules:
      print("activity name: ",schedule.activityName)
      print(" ","activity id: ", schedule.activityId)
      print(" ","schedule id: ", schedule.scheduleId)
      print(" ","schedule date: ", schedule.schedule_date)
      print(" ","schedule: ", schedule.schedule, "\n")
      


  except Exception as e:
    logging.error("failed")
    logging.error("url: " + url)
    logging.error(e)
    return


###################################################################
# main
#
print('** Schedule App **')
print()

# eliminate traceback so we just get error message:
sys.tracebacklimit = 0

#
# what config file should we use for this session?
#
config_file = 'scheduleapp-config.ini'

print("What config file to use for this session?")
print("Press ENTER to use default (scheduleapp-config.ini),")
print("otherwise enter name of config file>")
s = input()

if s == "":  # use default
  pass  # already set
else:
  config_file = s

#
# does config file exist?
#
if not pathlib.Path(config_file).is_file():
  print("**ERROR: config file '", config_file, "' does not exist, exiting")
  sys.exit(0)

#
# setup base URL to web service:
#
configur = ConfigParser()
configur.read(config_file)
baseurl = 'https://schedule-app--benmaisel1.repl.co'
# baseurl = configur.get('client', 'webservice')

#
# main processing loop:
#
cmd = prompt()

while cmd != 0:
  #
  if cmd == 1:
    get_cabins(baseurl)
  elif cmd == 2:
    get_activities(baseurl)
  elif cmd == 3:
    generate_schedules(baseurl)
  elif cmd == 4:
    get_cabinCurrent_schedule(baseurl)
  elif cmd == 5:
    get_activityCurrent_schedule(baseurl)
  elif cmd == 6:
    get_pastCabin_schedule(baseurl)
  elif cmd == 7:
    get_pastActivity_schedule(baseurl)
  else:
    print("** Unknown command, try again...")
  #
  cmd = prompt()

#
# done
#
print()
print('** done **')
