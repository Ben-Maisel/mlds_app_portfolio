import numpy as np
import src.random


class QLearning:
    """
    QLearning reinforcement learning agent.

    Arguments:
      epsilon - (float) The probability of randomly exploring the action space
        rather than exploiting the best action.
      alpha - (float) The weighting to give current rewards in estimating Q. This 
        should range [0,1], where 0 means "don't change the Q estimate based on 
        current reward" 
      gamma - (float) This is the weight given to expected future rewards when 
        estimating Q(s,a). It should be in the range [0,1]. Here 0 means "don't
        incorporate estimates of future rewards into the reestimate of Q(s,a)"

      See page 131 of Sutton and Barto's Reinforcement Learning book for
        pseudocode and for definitions of alpha, gamma, epsilon 
        (http://incompleteideas.net/book/RLbook2020.pdf).  
    """

    def __init__(self, epsilon=0.2, alpha=0.5, gamma=0.5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma

    def fit(self, env, steps=1000, num_bins=100):
        """
        Trains an agent using Q-Learning on an OpenAI Gymnasium Environment.

        See page 131 of Sutton and Barto's book Reinforcement Learning for
        pseudocode (http://incompleteideas.net/book/RLbook2020.pdf).
        Initialize your parameters as all zeros. Choose actions with
        an epsilon-greedy approach Note that unlike the pseudocode, we are
        looping over a total number of steps, and not a total number of
        episodes. This allows us to ensure that all of our trials have the same
        number of steps--and thus roughly the same amount of computation time.

        See (https://gymnasium.farama.org/) for examples of how to use the OpenAI
        Gymnasium Environment interface.

        In every step of the fit() function, you should sample
            two random numbers using functions from `src.random`.
            1.  First, use either `src.random.rand()` or `src.random.uniform()`
                to decide whether to explore or exploit.
            2. Then, use `src.random.choice` or `src.random.randint` to decide
                which action to choose. Even when exploiting, you should make a
                call to `src.random` to break (possible) ties.

        Please don't use `np.random` functions; use the ones from `src.random`!
        Please do not use `env.action_space.sample()`!

        Hints:
          - Use env.action_space.n and env.observation_space.n to get the
            number of available actions and states, respectively.
          - Remember to reset your environment at the end of each episode. To
            do this, call env.reset() whenever the value of "terminated or truncated" returned
            from env.step() is True.
          - In addition to resetting the environment, calling env.reset() will
            return the environment's initial state.
          - When choosing to exploit the best action rather than exploring,
            do not use np.argmax: it will deterministically break ties by
            choosing the lowest index of among the tied values. Instead,
            please *randomly choose* one of those tied-for-the-largest values.

        Arguments:
          env - (Env) An OpenAI Gymnasium environment with discrete actions and
            observations. See the OpenAI Gymnasium documentation for example use
            cases (https://gymnasium.farama.org/api/core/).
          steps - (int) The number of actions to perform within the environment
            during training.

        Returns:
          state_action_values - (np.array) The values assigned by the algorithm
            to each state-action pair as a 2D numpy array. The dimensionality
            of the numpy array should be S x A, where S is the number of
            states in the environment and A is the number of possible actions.
          rewards - (np.array) A 1D sequence of averaged rewards of length num_bins.
            Let s = int(np.ceil(steps / num_bins)), then rewards[0] should
            contain the average reward over the first s steps, rewards[1]
            should contain the average reward over the next s steps, etc.
            Please note that: The total number of steps will not always divide evenly by the 
            number of bins. This means the last group of steps may be smaller than the rest of 
            the groups. In this case, we can't divide by s to find the average reward per step 
            because we have less than s steps remaining for the last group.
        """
        # set up rewards list, Q(s, a) table
        n_actions, n_states = env.action_space.n, env.observation_space.n
        state_action_values = np.zeros((n_states, n_actions))
        avg_rewards = np.zeros([num_bins])
        all_rewards = []

        current_state, _ = env.reset()

        # steps per bin to help with averages
        steps_per_bin = np.ceil(steps / num_bins).astype(int)
        bin_idx = 0

        for step in range(steps): # for each step
            if src.random.rand() < self.epsilon: # if less than the epsilon, explore
                action = src.random.choice(list(range(n_actions))) # explore by choosing a random action
            else: # otherwise, exploit
                
                if isinstance(current_state, (tuple, list, np.ndarray)): # so that i can index
                  current_state = current_state[0]

                best = np.max(state_action_values[current_state]) # get the best value from state action values
                best_action = [action for action in range(n_actions) if state_action_values[current_state, action] == best] # get all the actions with the best value (there can be multiple)
                action = src.random.choice(best_action) # randomly choose one to effectively randomly break ties

            # execute the best actionn in the environment
            nextState, reward, terminated, truncated, info = env.step(action)
            all_rewards.append(reward) # add the reward to the array

            #update q according to the q learning update rule
            if isinstance(current_state, (tuple, list, np.ndarray)): # so that i can index
                  current_state = current_state[0]
            bestNextAction = np.max(state_action_values[nextState]) # max q for next state
            tdTarget = reward + self.gamma * bestNextAction # compute td target
            tdError = tdTarget - state_action_values[current_state, action] # compute error
            state_action_values[current_state, action] += self.alpha * tdError # adjust q with error

            if terminated or truncated:
                current_state = env.reset() # reset environment if terminated or truncated
            else:
                current_state = nextState # otherwise, set state to the next state

            # get the average reward for the current bin
            if (step + 1) % steps_per_bin == 0 or step == steps - 1:
                avg_rewards[bin_idx] = np.mean(all_rewards)
                all_rewards = []
                bin_idx += 1

        return state_action_values, np.array(avg_rewards)

    def predict(self, env, state_action_values):
        """
        Runs prediction on an OpenAI environment using the policy defined by
        the QLearning algorithm and the state action values. Predictions are
        run for exactly one episode. Note that one episode may produce a
        variable number of steps.

        Hints:
          - You should not update the state_action_values during prediction.
          - Exploration is only used in training. During prediction, you
            should only "exploit."
          - In addition to resetting the environment, calling env.reset() will
            return the environment's initial state
          - You should use a loop to predict over each step in an episode until
            it terminates by returning `terminated or truncated=True`.
          - When choosing to exploit the best action, do not use np.argmax: it
            will deterministically break ties by choosing the lowest index of
            among the tied values. Instead, please *randomly choose* one of
            those tied-for-the-largest values.

        Arguments:
          env - (Env) An OpenAI Gymnasium environment with discrete actions and
            observations. See the OpenAI Gymnasium documentation for example use
            cases (https://gymnasium.farama.org/).
          state_action_values - (np.array) The values assigned by the algorithm
            to each state-action pair as a 2D numpy array. The dimensionality
            of the numpy array should be S x A, where S is the number of
            states in the environment and A is the number of possible actions.

        Returns:
          states - (np.array) The sequence of states visited by the agent over
            the course of the episode. Does not include the starting state.
            Should be of length K, where K is the number of steps taken within
            the episode.
          actions - (np.array) The sequence of actions taken by the agent over
            the course of the episode. Should be of length K, where K is the
            number of steps taken within the episode.
          rewards - (np.array) The sequence of rewards received by the agent
            over the course  of the episode. Should be of length K, where K is
            the number of steps taken within the episode.
        """

        # setup
        n_actions, n_states = env.action_space.n, env.observation_space.n
        states, actions, rewards = [], [], []

        # reset environment before your first action
        current_state, _ = env.reset()
        
        while True:
            
            if isinstance(current_state, (tuple, list, np.ndarray)): # so that i can index
                current_state = current_state[0]

            best = np.max(state_action_values[current_state]) # get the best value from state action values
            best_action = [action for action in range(n_actions) if state_action_values[current_state, action] == best] # get all the actions with the best value (there can be multiple)
            action = src.random.choice(best_action) # randomly choose one to effectively randomly break ties

            # execute the best actionn in the environment
            nextState, reward, terminated, truncated, info = env.step(action)

            #update arrays
            states.append(nextState)
            actions.append(action)
            rewards.append(reward)

            # break the loop if the episode has ended
            if terminated or truncated:
                break
            
            # otherwise, next state and repeat
            current_state = nextState


        return np.array(states), np.array(actions), np.array(rewards) # convert lists to arrays and return
            
