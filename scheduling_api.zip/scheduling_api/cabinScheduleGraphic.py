from PIL import Image, ImageDraw, ImageFont

def create_schedule_image(schedule, cabin_name): # helper function to make the schedule image
    
    square_width, square_height = 100, 100 # size of each sqaure, represent a period on the image
    offset_width, offset_height = 100, 50  # offset start so we have room to draw in the indices
    image_width, image_height = square_width * 5 + offset_width, square_height * 8 + offset_height # total image size

    
    image = Image.new('RGB', (image_width, image_height), color='white') # creates a new image with a white background
    draw = ImageDraw.Draw(image)

    try:
        font = ImageFont.truetype("arial.ttf", 15) # try to select a font, if not, just use the default
    except IOError:
        font = ImageFont.load_default()

    
    cabin_text = f"Cabin: {cabin_name}"
    draw.text((10, 10), cabin_text, fill='black', font=font) # write the cabin name on the image first

    # Draw the period indices on top
    for period in range(1, 5):
        period_text = f"Period {period}"
        x = offset_width + (period - 1) * square_width + square_width // 2 # format the period index text and then draw it in
        draw.text((x, 10), period_text, fill='black', font=font, anchor="mm")

    # Draw days and activities
    for day, periods in enumerate(schedule, start=1): # same idea, format the day index and then draw it in
        # Draw day index on the left
        day_text = f"Day {day}"
        y = 5 + offset_height + (day - 1) * square_height + square_height // 2
        draw.text((10, y), day_text, fill='black', font=font)

        for period, activity in enumerate(periods.values()):
            x0 = offset_width + period * square_width
            y0 = offset_height + (day - 1) * square_height # for each period, get its proper location in the image
            x1 = x0 + square_width
            y1 = y0 + square_height

            draw.rectangle([x0, y0, x1, y1], outline='black') # draw the cell in

            # Draw activity name
            w, h = draw.textsize(activity[0], font=font) #write the text in the centre of the cell
            draw.text((x0 + (square_width - w)/2, y0 + (square_height - h)/2), activity[0], fill='black', font=font)

    # Save and display the image
    image_file = f'{cabin_name}_current_schedule.png'
    image.save(image_file) # save the image and display it
    image.show()

    return image_file



#--------------------------------------------------------------------------------------------------------------------------------

def create_pastschedule_image(schedule, schedule_date, cabin_name): # helper function to make the schedule image
    
    square_width, square_height = 100, 100 # size of each sqaure, represent a period on the image
    offset_width, offset_height = 100, 50  # offset start so we have room to draw in the indices
    image_width, image_height = square_width * 5 + offset_width, square_height * 8 + offset_height # total image size

    
    image = Image.new('RGB', (image_width, image_height), color='white') # creates a new image with a white background
    draw = ImageDraw.Draw(image)

    try:
        font = ImageFont.truetype("arial.ttf", 15) # try to select a font, if not, just use the default
    except IOError:
        font = ImageFont.load_default()

    
    cabin_text = f"Cabin: {cabin_name}\n Date:{schedule_date}"
    draw.text((10, 10), cabin_text, fill='black', font=font) # write the cabin name on the image first

    # Draw the period indices on top
    for period in range(1, 5):
        period_text = f"Period {period}"
        x = offset_width + (period - 1) * square_width + square_width // 2 # format the period index text and then draw it in
        draw.text((x, 10), period_text, fill='black', font=font, anchor="mm")

    # Draw days and activities
    for day, periods in enumerate(schedule, start=1): # same idea, format the day index and then draw it in
        # Draw day index on the left
        day_text = f"Day {day}"
        y = 5 + offset_height + (day - 1) * square_height + square_height // 2
        draw.text((10, y), day_text, fill='black', font=font)

        for period, activity in enumerate(periods.values()):
            x0 = offset_width + period * square_width
            y0 = offset_height + (day - 1) * square_height # for each period, get its proper location in the image
            x1 = x0 + square_width
            y1 = y0 + square_height

            draw.rectangle([x0, y0, x1, y1], outline='black') # draw the cell in

            # Draw activity name
            w, h = draw.textsize(activity[0], font=font) #write the text in the centre of the cell
            draw.text((x0 + (square_width - w)/2, y0 + (square_height - h)/2), activity[0], fill='black', font=font)

    # Save and display the image
    image_file = f'{cabin_name}_current_schedule.png'
    image.save(image_file) # save the image and display it
    image.show()

    return image_file
