import numpy as np


def euclidean_distances(X, Y):
    """Compute pairwise Euclidean distance between the rows of two matrices X (shape MxK)
    and Y (shape NxK). The output of this function is a matrix of shape MxN containing
    the Euclidean distance between two rows.

    (Hint: You're free to implement this with numpy.linalg.norm)

    Arguments:
        X {np.ndarray} -- First matrix, containing M examples with K features each.
        Y {np.ndarray} -- Second matrix, containing N examples with K features each.

    Returns:
        D {np.ndarray}: MxN matrix with Euclidean distances between rows of X and rows of Y.
    """

    # d^2(x,y) = x^2 + y^2 - 2(x.y)

    x_formed = np.sum(X**2, axis=1).reshape(-1,1) # square each element, sum the row of squared elements, reshape the result into column vector for broadcasting
    y_formed = np.sum(Y**2, axis=1).reshape(1,-1) # square each element, sum the row of squared elements, reshape the result into row vector for broadcasting
    dot_product = np.dot(X, Y.T) # compute the dot product between X and transposed Y, result matrix shape MxN, each element (i, j) is dot between i-th row of X, j-th row of Y.
    dist = np.sqrt((x_formed + y_formed) - (2 * dot_product))
    return dist


def manhattan_distances(X, Y):
    """Compute pairwise Manhattan distance between the rows of two matrices X (shape MxK)
    and Y (shape NxK). The output of this function is a matrix of shape MxN containing
    the Manhattan distance between two rows.

    (Hint: You're free to implement this with numpy.linalg.norm)

    Arguments:
        X {np.ndarray} -- First matrix, containing M examples with K features each.
        Y {np.ndarray} -- Second matrix, containing N examples with K features each.

    Returns:
        D {np.ndarray}: MxN matrix with Manhattan distances between rows of X and rows of Y.
    """
    # |x2 - x1| + |y2-y1|

    M = X.shape[0] # get num rows x
    N = Y.shape[0] # get num rows y

    d = np.zeros((M, N)) # initialize matrix m X n to store the results

    for i in range(M): # for each row in x
        for j in range(N): # for each row in y
            d[i, j] = np.sum(np.abs(X[i] - Y[j])) # get the absolute value of the difference between the ith row of x and the jth row of y and sum them, store in matrix
    
    return d


def cosine_distances(X, Y):
    """Compute pairwise Cosine distance between the rows of two matrices X (shape MxK)
    and Y (shape NxK). The output of this function is a matrix of shape MxN containing
    the Cosine distance between two rows.

    (Hint: You're free to implement this with numpy.linalg.norm)

    Arguments:
        X {np.ndarray} -- First matrix, containing M examples with K features each.
        Y {np.ndarray} -- Second matrix, containing N examples with K features each.

    Returns:
        D {np.ndarray}: MxN matrix with Cosine distances between rows of X and rows of Y.
    """
    # 1 - (a.b) / (|a||b|)

    x_formed = np.linalg.norm(X, axis=1, keepdims=True) # get the norms of each row of x
    y_formed = np.linalg.norm(Y, axis=1, keepdims=True).T # get the norms of each row of y

    # to prevent division by 0, if the norm of a row is 0, replace it with the smallest postive float value
    x_formed[x_formed == 0] = np.finfo(float).eps
    y_formed[y_formed == 0] = np.finfo(float).eps

    x_normalized = X / x_formed # normalize rows of x (unit lengths)
    y_normalized = Y / y_formed.T # normalize rows of y (unit lengths)

    cos_sim = np.dot(x_normalized, y_normalized.T) # get dot product of x and transpose of y, result is m x n matrix where each element i,j is cos sim between x[i], y[j]

    cos_dist = 1 - cos_sim

    return cos_dist

