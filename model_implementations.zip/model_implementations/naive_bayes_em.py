# DONE

import warnings
import numpy as np

from src.utils import softmax, stable_log_sum
from src.sparse_practice import flip_bits_sparse_matrix
from src.naive_bayes import NaiveBayes


class NaiveBayesEM(NaiveBayes):
    """
    A NaiveBayes classifier for binary data, that uses both unlabeled and
        labeled data in the Expectation-Maximization algorithm

    Note that the class definition above indicates that this class
        inherits from the NaiveBayes class. This means it has the same
        functions as the NaiveBayes class unless they are re-defined in this
        function. In particular you should be able to call `self.predict_proba`
        using your implementation from `src/naive_bayes.py`.
    """

    def __init__(self, max_iter=10, smoothing=1):
        """
        Args:
            max_iter: the maximum number of iterations in the EM algorithm
            smoothing: controls the smoothing behavior when computing beta
        """
        self.max_iter = max_iter
        self.smoothing = smoothing

    def initialize_params(self, vocab_size, n_labels):
        """
        Initialize self.alpha such that
            `p(y_i = k) = 1 / n_labels`
            for all k
        and initialize self.beta such that
            `p(w_j | y_i = k) = 1/2`
            for all j, k.
        """

        self.alpha = np.ones(n_labels) / n_labels # initialize alpha as specified
        self.beta = np.ones((vocab_size, n_labels)) / 2 # initialize beta as specified


    def fit(self, X, y):
        """
        Compute self.alpha and self.beta using the training data.
        You should store log probabilities to avoid underflow.
        This function *should* use unlabeled data within the EM algorithm.

        During the E-step, use the NaiveBayes superclass self.predict_proba to
            infer a distribution over the labels for the unlabeled examples.
            Note: you should *NOT* overwrite the provided `y` array with the
            true labels with your predicted labels. 

        During the M-step, update self.alpha and self.beta, similar to the
            `fit()` call from the NaiveBayes superclass. Unlike NaiveBayes,
            you will use unlabeled data. When counting the words in an
            unlabeled document in the computation for self.beta, to replace
            the missing binary label y, you should use the predicted probability
            p(y | X) inferred during the E-step above.

        For help understanding the EM algorithm, refer to the lectures and
            the handout.

        self.alpha should contain the marginal probability of each class label.

        self.beta is an array of shape [n_vocab, n_labels]. self.beta[j, k]
            is the probability of seeing the word j in a document with label k.
            Remember to use self.smoothing. If there are M documents with label
            k, and the `j`th word shows up in L of them, then `self.beta[j, k]`.

        Note: if self.max_iter is 0, your function should call
            `self.initialize_params` and then break. In each
            iteration, you should complete both an E-step and
            an M-step.

        Don't worry about divide-by-zero RuntimeWarnings.

        Args: X, a sparse matrix of word counts; Y, an array of labels
        Returns: None
        """
        n_docs, vocab_size = X.shape
        n_labels = 2
        self.vocab_size = vocab_size

        self.initialize_params(vocab_size, n_labels)

        if self.max_iter == 0: # if there are no iterations, then just return
            return
        
        for i in range(self.max_iter): # for each iteration
            
            # E STEP!
            probs = np.zeros((n_docs, n_labels)) # intialize array to store the probs

            for doc in range(n_docs): # for each document
                if np.isnan(y[doc]):
                    probs[doc] = self.predict_proba(X[doc]) # if the label is nan, predict it using the method
                else:
                    probs[doc, int(y[doc])] = 1 # otherwise, set the probs to 1 since label is known

            # M STEP!
            num_class = np.zeros(n_labels) # initilaize a counter
            num_word = np.zeros((vocab_size, n_labels)) # initialize a counter

            for d in range(n_docs): # for each doc
                label = y[d] # get the label for that doc
                has_label = not np.isnan(label) # boolean for whether or not the doc has a label

                for l in range(n_labels): # for each label
                    if has_label: # if the document is labeled
                        if l == int(label): # update the counter for the correct label
                            num_class[l] += 1
                            num_word[:,l] += X[d].toarray().flatten() # convert to dense array, flatten, update word counter
                    else: # no label case
                        p = probs[d,l] # get the predcited prob for that doc and label
                        num_class[l] += p # update counter
                        num_word[:,l] += X[d].toarray().flatten() * p # scale and update counter

            
            self.alpha = np.divide(num_class, num_class.sum()) # update marginal probs
            self.beta = np.zeros((vocab_size, n_labels)) # reset beta array so it can be updated

            for label in range(n_labels): # for each label
                smoothed_total = num_class[label] + (self.smoothing * 2) # smooth the counter just in case
                for word in range(vocab_size): # for each word
                    smoothed_count = num_word[word, label] + self.smoothing # smooth the counter just in case
                    self.beta[word, label] = smoothed_count / smoothed_total # update beta




    def likelihood(self, X, y):
        r"""
        Using the self.alpha and self.beta that were already computed in
            `self.fit`, compute the LOG likelihood of the data. You should use
            logs to avoid underflow.  This function *should* use unlabeled
            data.

        For unlabeled data, we predict `p(y_i = y' | X_i)` using the
            previously-learned p(x|y, beta) and p(y | alpha).
            For labeled data, we define `p(y_i = y' | X_i)` as
            1 if `y_i = y'` and 0 otherwise; this is because for labeled data,
            the probability that the ith example has label y_i is 1.

        The tricky aspect of this likelihood is that we are simultaneously
            computing $p(y_i = y' | X_i, \alpha^t, \beta^t)$ to predict a
            distribution over our latent variables (the unobserved $y_i$) while
            at the same time computing the probability of seeing such $y_i$
            using $p(y_i =y' | \alpha^t)$.

        Note: In implementing this equation, it will help to use your
            implementation of `stable_log_sum` to avoid underflow. See the
            documentation of that function for more details.

        We will provide a detailed writeup for this likelihood in the PDF
            handout.

        Don't worry about divide-by-zero RuntimeWarnings.

        Args: X, a sparse matrix of word counts; Y, an array of labels
        Returns: the log likelihood of the data.
        """

        assert hasattr(self, "alpha") and hasattr(self, "beta"), "Model not fit!"

        n_docs, vocab_size = X.shape
        n_labels = 2

        log_likelihood = 0 # intilialize likelihood to 0

        probs = np.zeros((n_docs, n_labels)) # intialize an array to store the probs

        for i in range(n_docs): # for each doc
            if np.isnan(y[i]): # if the doc is unlabeled
                probs[i] = self.predict_proba(X[i]) # predict the labels
            else: # if the doc is labeled
                probs[i, int(y[i])] = 1 # set to 1 since label is known

        for i in range(n_docs): # for each doc
            doc_probs = np.zeros(n_labels) # initilaize var for the probs for the current doc

            for label in range(n_labels): # for each label
                prob_label = np.log(probs[i, label]) # get log probs for that label for that doc
                alpha_label = np.log(self.alpha[label]) # get the alpha for that label

                prob_given_label = 0 # initilaize to 0 to store prob
                for word in range(vocab_size): # for each word
                    if X[i, word] != 0: # if word is present
                        prob_given_label += X[i, word] * np.log(self.beta[word, label]) # scale by beta and update probs
                    if X[i, word] != 1: #if word is absent
                        prob_given_label += (1-X[i, word]) * np.log(1-self.beta[word, label]) # scale by beta and update probs
                
                doc_probs[label] = prob_given_label + alpha_label + prob_label # update the probs for that label for that doc
            
            log_likelihood += stable_log_sum(doc_probs.reshape(1,-1)) # update the likelihood using the stable log sum
        
        return log_likelihood

