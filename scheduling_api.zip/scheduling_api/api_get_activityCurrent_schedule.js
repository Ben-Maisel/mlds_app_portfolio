// get request to return current activity schedules from our sql database

const dbConnection = require('./database.js');                    
const { activityToIdMap } = require('./data.js');
const { GetObjectCommand } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');
const { streamToString } = require('./function_definitions.js');

exports.get_activityCurrent_schedule = async (req, res) => {
  console.log('call to /get_activityCurrent_schedules...');
  try {
    const activitiesRequesting = Array.isArray(req.body) ? req.body : []; // Get activities from request body

    const activityIds = activitiesRequesting.map(activity => activityToIdMap.get(activity)).filter(id => id !== undefined); //only get valid activity ids

    if (activityIds.length === 0) {
      return res.status(400).json({ message: "No valid activity IDs found in the request." }); //if no activities, error
    }

    const query = 'SELECT activityid, activity_name, current_schedule_key FROM activities WHERE activityid IN (?)'; //query to get keys

    // Query the database
    const rows = await new Promise((resolve, reject) => {  //make query and store results
      dbConnection.query(query, [activityIds], (err, results) => {
        if (err) {
          return reject(err); //this will cause the promise to be rejected if there is an error
        }
        resolve(results); //if there is no error, resolve the results to fullfill the promise
      });
    });

    if (!rows || rows.length === 0) {
      return res.status(404).json({ message: "No schedules found for the requested activities." }); //if no schedules, error
    }


    const schedule_data = rows.map(row => ({
      activityId: row.activityid,
      scheduleKey: row.current_schedule_key,
      activityName : row.activity_name//format the rds response
    }));

    schedules = []; //structure to return the schedules

    for (const item of rows) { // for each activity, get the schedule from s3 and stick it in return structure
      const command = new GetObjectCommand({
        Bucket: s3_bucket_name,
        Key: item.current_schedule_key
      });

      const response = await s3.send(command);
      const contents = await streamToString(response.Body); //our helper function defined in function definitions
      const contents_formatted = JSON.parse(contents);
      schedules.push({ activityName : item.activity_name, activityId: item.activityid, schedule: contents_formatted });
    }


    console.log("Done!")
    res.status(200).json({ message: "Schedules retrieved successfully", data: schedules });

  } catch (err) {
    console.error("message: ", err);
    res.status(400).json({ message: "Error retrieving schedules", error: err.message });
  }
};

