#Imports
import socket
import re
import sys

ipv4 = socket.AF_INET
TCP = socket.SOCK_STREAM

def create_socket(ipv = ipv4, protocol = TCP):
    return socket.socket(ipv, protocol)

def get_ip(hostname):
    return socket.gethostbyname(hostname)

destination_port = 80

def parse_url(url):
    
    # remove the first bit
    if url.startswith("http://"):
        url = url[len("http://"):]
    
    # extract the port and path
    if ":" in url:
        hostname_port, path = url.split("/", 1) if "/" in url else (url, "")
        hostname, port = hostname_port.split(":")
        port = int(port)
    else:
        hostname, path = url.split("/", 1) if "/" in url else (url, "")
        port = destination_port
    
    path = "/" + path if path else "/"
    
    return hostname, port, path

def receive_response(client_socket):
    
    # make empty string to populate with response
    response = ""

    while True:
        data = client_socket.recv(2048)
        if not data:
            break
        response += data.decode()
    
    client_socket.close()
    return response

def get_status_code(status_line):
    parts = status_line.split(" ")
    if len(parts) >= 2:
        return int(parts[1])
    return None

def get_status_message(status_line):
    parts = status_line.split(" ")
    if len(parts) >= 3:
        return " ".join(parts[2:])
    return None

def get_header_value(headers, header_name):
    for header in headers:
        if header.lower().startswith(header_name.lower()):
            return header.split(":", 1)[1].strip()
    return None

def parse_response(response):
    
    header_section, body = response.split("\r\n\r\n", 1)
    headers = header_section.splitlines()

    status_line = headers[0]
    status_code = get_status_code(status_line)
    status_message = get_status_message(status_line)
    
    content_length = get_header_value(headers, "Content-Length")
    content_type = get_header_value(headers, "Content-Type")
    location = get_header_value(headers, "Location")

    
    return {
        "status_code": status_code,
        "status_message": status_message,
        "content_type": content_type,
        "content_length": content_length,
        "location": location,
        "body": body
    }

redirect_counter = 0

def fetch_url(url):
    
    url = url.lower()
    
    if not url.startswith("http://"):
        sys.exit("ERROR: URL MUST BEGIN WITH HTTP")
    
    global redirect_counter
    if redirect_counter >= 10:
        sys.exit("ERROR: REDIRECTED TOO MANY TIMES")

    # Step 1 --> Parse the URL manually
    hostname, port, path = parse_url(url)
    
    # step 2 --> get IP
    ip_address = get_ip(hostname)

    # step 3 --> create socket
    client_socket = create_socket()

    # step 4 --> connect to server
    client_socket.connect((ip_address, port))
    
    # step 5 --> make the request
    request = f"GET {path} HTTP/1.0\r\nHost: {hostname}\r\n\r\n"
    client_socket.sendall(request.encode())

    # Step 6 --> get response
    response = receive_response(client_socket)
    parsed_response = parse_response(response)
    
    #Step 7 --> handle status codes
    if parsed_response['status_code'] == 200:
        redirect_counter = 0
        print(parsed_response['body'])
        sys.exit(0)
    
    if parsed_response['status_code'] in [301, 302]:
        
        if parsed_response['location'].startswith("https"):
            print(f"Redirected to: {parsed_response['location']}", file=sys.stderr)
            sys.exit("ERROR: REDIRECTING TO HTTPS")
        
        print(f"Redirected to: {parsed_response['location']}", file=sys.stderr)
        redirect_counter += 1
        return fetch_url(parsed_response['location'])
    
    if parsed_response['status_code'] >= 400:
        
        if parsed_response['content_type'].startswith("text/html"):
            print(parsed_response['body'])
            sys.exit(1)
            
        sys.exit(1)

if len(sys.argv) > 2:
    sys.exit("TOO MANY ARGS PASSED")

url = sys.argv[1]
fetch_url(url)